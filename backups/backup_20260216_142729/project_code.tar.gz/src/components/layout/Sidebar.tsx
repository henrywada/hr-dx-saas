import React from 'react';
import Link from 'next/link';
import { usePathname } from 'next/navigation';
import { SIDEBAR_MENU } from '@/config/dashboard-config';
import { ChevronRight, ExternalLink } from 'lucide-react';

export function Sidebar() {
  const pathname = usePathname();

  const isActive = (path: string) => {
      if (path === '/top' && pathname === '/top') return true;
      if (path !== '/top' && pathname?.startsWith(path)) return true;
      return false;
  };

  return (
    <aside className="w-64 bg-slate-50/50 border-r border-slate-200 flex-col hidden md:flex shrink-0">
      <div className="flex-1 overflow-y-auto py-6 px-4 space-y-8">
        
        {/* Main Navigation */}
        <div>
          <h3 className="text-xs font-semibold text-slate-400 uppercase tracking-wider mb-3 px-3">
            メインメニュー
          </h3>
          <nav className="space-y-1">
            {SIDEBAR_MENU.map((item) => {
              const Icon = item.icon;
              const active = isActive(item.href);
              
              return (
                <Link 
                  key={item.label} 
                  href={item.href}
                  className={`flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium transition-all duration-200 group relative ${
                    active 
                      ? "bg-white text-accent-orange shadow-sm border border-slate-100 dark:bg-slate-800 dark:border-slate-700" 
                      : "text-slate-600 hover:bg-white hover:text-slate-900 hover:shadow-sm"
                  }`}
                >
                  {active && (
                      <div className="absolute left-0 top-1/2 -translate-y-1/2 w-1 h-6 bg-accent-orange rounded-r-full"></div>
                  )}
                  <Icon className={`w-5 h-5 transition-colors ${active ? "text-accent-orange" : "text-slate-400 group-hover:text-slate-600"}`} />
                  <span className="flex-1">{item.label}</span>
                  {active && <ChevronRight className="w-4 h-4 text-accent-orange opacity-50" />}
                </Link>
              );
            })}
          </nav>
        </div>

        {/* Quick Access / Favorites (Mock) */}
        <div>
           <h3 className="text-xs font-semibold text-slate-400 uppercase tracking-wider mb-3 px-3 flex justify-between items-center group cursor-pointer hover:text-slate-600">
             <span>お気に入り</span>
             <span className="opacity-0 group-hover:opacity-100 text-[10px] bg-slate-200 px-1.5 rounded text-slate-600">編集</span>
           </h3>
           <nav className="space-y-1">
              <Link href="#" className="flex items-center gap-3 px-3 py-2 rounded-lg text-sm text-slate-600 hover:bg-white hover:text-slate-900 hover:shadow-sm transition-all group">
                 <div className="w-1.5 h-1.5 rounded-full bg-blue-400"></div>
                 <span>給与明細発行</span>
              </Link>
              <Link href="#" className="flex items-center gap-3 px-3 py-2 rounded-lg text-sm text-slate-600 hover:bg-white hover:text-slate-900 hover:shadow-sm transition-all group">
                 <div className="w-1.5 h-1.5 rounded-full bg-pink-400"></div>
                 <span>年末調整対応</span>
              </Link>
           </nav>
        </div>

        {/* System Status / Announcements */}
        <div className="bg-gradient-to-br from-slate-100 to-white p-4 rounded-xl border border-slate-200/60 shadow-sm">
           <h4 className="font-semibold text-sm text-slate-800 mb-2 flex items-center gap-2">
             <span className="w-2 h-2 bg-green-500 rounded-full animate-pulse"></span>
             システム稼働中
           </h4>
           <div className="text-xs text-slate-500 space-y-2">
              <p>特に問題は報告されていません。</p>
              <Link href="#" className="text-accent-orange hover:underline flex items-center gap-1 mt-1">
                 ステータス詳細 <ExternalLink className="w-3 h-3" />
              </Link>
           </div>
        </div>

      </div>
      
      {/* User / Bottom Actions */}
      <div className="p-4 border-t border-slate-200">
         <button className="w-full flex items-center justify-center gap-2 py-2 text-sm font-medium text-slate-500 hover:text-slate-700 hover:bg-slate-100 rounded-lg transition-colors">
            ヘルプ＆サポート
         </button>
      </div>
    </aside>
  );
}