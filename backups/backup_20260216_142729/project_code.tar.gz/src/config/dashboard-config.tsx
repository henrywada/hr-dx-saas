import { 
  LayoutDashboard, 
  Users, 
  FolderKanban, 
  FileText, 
  Settings, 
  Building2, 
  BarChart3, 
  Briefcase 
} from 'lucide-react';

export interface MenuItem {
  label: string;
  href: string;
  icon: any;
  active?: boolean;
}

export interface DashboardCard {
  title: string;
  value: string;
  trend: string;
  trendUp: boolean;
  icon: any;
  color: string;
}

// 左サイドメニューの定義
export const SIDEBAR_MENU: MenuItem[] = [
  { label: 'ダッシュボード', href: '/top', icon: LayoutDashboard, active: true },
  { label: 'プロジェクト', href: '/projects', icon: FolderKanban },
  { label: 'チーム', href: '/team', icon: Users },
  { label: 'ドキュメント', href: '/docs', icon: FileText },
  { label: 'レポート', href: '/reports', icon: BarChart3 },
  { label: '業務ツール', href: '/tools', icon: Briefcase },
];

// ダッシュボードのメインコンテンツ（カード）の定義
export const DASHBOARD_CARDS: DashboardCard[] = [
  { 
    title: '総従業員数', 
    value: '142名', 
    trend: '+4名 (先月比)', 
    trendUp: true, 
    icon: Users,
    color: 'bg-blue-500'
  },
  { 
    title: '稼働プロジェクト', 
    value: '12件', 
    trend: '+2件 (先月比)', 
    trendUp: true, 
    icon: FolderKanban,
    color: 'bg-accent-orange' 
  },
  { 
    title: '今月の経費申請', 
    value: '¥2,450,000', 
    trend: '-5% (先月比)', 
    trendUp: true, 
    icon: FileText,
    color: 'bg-green-500'
  },
  { 
    title: 'システム稼働率', 
    value: '99.9%', 
    trend: '安定', 
    trendUp: true, 
    icon: Settings,
    color: 'bg-purple-500'
  },
];
