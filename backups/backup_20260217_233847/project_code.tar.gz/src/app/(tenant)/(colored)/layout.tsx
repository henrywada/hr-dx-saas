"use client";

import React from "react";
import { Header } from "@/components/layout/Header_adm";
import { Sidebar } from "@/components/layout/Sidebar";
import { Footer } from "@/components/layout/Footer";
import { CURRENT_USER, CURRENT_USER_ROLE } from "@/lib/auth-mock";

export default function TenantLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  // 開発用モックロールを使用
  const role = CURRENT_USER_ROLE;
  const user = CURRENT_USER;

  // 背景色を強制するためのスタイル
  const bgStyle = { backgroundColor: "#E5EBFF" };

  return (
    <div className="flex flex-col h-screen font-sans text-slate-900 overflow-hidden" style={bgStyle}>
      {/* Header (Sticky or Fixed if needed, currently part of flex flow) */}
      <Header role={role} userName={user.name} />

      {/* Main Layout Area */}
      <div className="flex flex-1 overflow-hidden" style={bgStyle}>
        {/* Left Sidebar (Fixed width) */}
        <Sidebar />

        {/* Main Content (Flexible width, Scrollable) */}
        <main className="flex-1 flex flex-col min-w-0 overflow-hidden relative" style={bgStyle}>
          {/* Scrollable Content Region */}
          <div className="flex-1 overflow-y-auto scroll-smooth">
             {/* Page Content */}
             <div className="p-6 md:p-8 max-w-7xl mx-auto w-full">
                {children}
             </div>
          </div>
          
          {/* Footer at the bottom of Main area */}
          <Footer />
        </main>
      </div>
    </div>
  );
}