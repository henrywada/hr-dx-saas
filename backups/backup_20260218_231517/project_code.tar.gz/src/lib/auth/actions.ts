'use server';

// createServerClient を createClient に変更
import { createClient } from '@/lib/supabase/server';
import { redirect } from 'next/navigation';
import { AuthSession } from '@/types/auth';

/**
 * ログイン処理（Server Action）
 */
export async function signInAction(email: string, password: string) {
  // ここも createClient() に変更
  const supabase = await createClient();

  const { data, error } = await supabase.auth.signInWithPassword({
    email,
    password,
  });

  if (error) {
    return { success: false, error: error.message };
  }

  if (data.session) {
    const session: AuthSession = {
      user: {
        id: data.user.id,
        email: data.user.email,
        tenant_id: data.user.user_metadata?.tenant_id,
      },
    };

    // リダイレクト先の判定
    let redirectPath = '/login';
    if (session.user.id === 'e97488f9-02be-4b0b-9dc9-ddb0c2902999') {
      redirectPath = '/system-master';
    } else if (session.user.tenant_id) {
      redirectPath = `/${session.user.tenant_id}/top`;
    }

    redirect(redirectPath);
  }

  return { success: true };
}