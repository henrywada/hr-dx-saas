import { NextResponse } from 'next/server';

export async function GET() {
  // 本来はDBから日次データを集計しますが、まずは表示用にデータを返します
  const data = [
    { date: '02/10', value: 30 },
    { date: '02/11', value: 45 },
    { date: '02/12', value: 28 },
    { date: '02/13', value: 60 },
    { date: '02/14', value: 50 },
    { date: '02/15', value: 70 },
    { date: '02/16', value: 65 },
  ];
  return NextResponse.json(data);
}