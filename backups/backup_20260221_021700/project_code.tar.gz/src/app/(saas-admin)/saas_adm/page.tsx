import React from 'react';
import DashboardUI from '@/features/saas-dashboard/components/DashboardUI';
import { getSaasStats, getSaasTenants, getSaasActivity } from '@/features/saas-dashboard/queries';

export default async function DashboardPage() {
  // サーバーサイドで直接Supabaseを叩き、データを取得
  const [stats, tenants, activityData] = await Promise.all([
    getSaasStats(),
    getSaasTenants(),
    getSaasActivity()
  ]);

  // 取ってきたデータをただClient Componentに渡すだけ
  return <DashboardUI stats={stats} tenants={tenants} activityData={activityData} />;
}