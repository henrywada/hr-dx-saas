export const APP_ROUTES = {
  AUTH: {
    LOGIN: '/login',
    SIGNUP: '/signup',
  },
  TENANT: {
    PORTAL: '/top',
    ADMIN: '/adm',
  },
  SAAS: {
    DASHBOARD: '/saas_adm',
  }
} as const;
