'use server';

import { createClient } from '@/lib/supabase/server';
import { revalidatePath } from 'next/cache';
import { APP_ROUTES } from '@/config/routes';

const ADM_PATH = APP_ROUTES.TENANT.ADMIN;

// =====================================================
// Division Actions
// =====================================================

export async function createDivision(data: {
  name: string;
  code?: string;
  layer?: number;
  parent_id?: string | null;
  tenant_id: string;
}) {
  const supabase = await createClient();
  const { data: result, error } = await supabase
    .from('divisions')
    .insert(data)
    .select()
    .single();

  if (error) {
    console.error('createDivision error:', error);
    return { success: false, error: error.message };
  }
  revalidatePath(`${ADM_PATH}/divisions`);
  return { success: true, data: result };
}

export async function updateDivision(id: string, updates: {
  name?: string;
  code?: string;
  layer?: number;
  parent_id?: string | null;
}) {
  const supabase = await createClient();
  const { data: result, error } = await supabase
    .from('divisions')
    .update(updates)
    .eq('id', id)
    .select()
    .single();

  if (error) {
    console.error('updateDivision error:', error);
    return { success: false, error: error.message };
  }
  revalidatePath(`${ADM_PATH}/divisions`);
  return { success: true, data: result };
}

export async function deleteDivision(id: string) {
  const supabase = await createClient();

  // まず所属従業員のdivision_idをnullに設定
  await supabase
    .from('employees')
    .update({ division_id: null })
    .eq('division_id', id);

  const { error } = await supabase
    .from('divisions')
    .delete()
    .eq('id', id);

  if (error) {
    console.error('deleteDivision error:', error);
    return { success: false, error: error.message };
  }
  revalidatePath(`${ADM_PATH}/divisions`);
  return { success: true };
}

// =====================================================
// Employee Actions
// =====================================================

export async function createEmployee(data: {
  name: string;
  employee_no?: string;
  division_id?: string | null;
  active_status?: string;
  is_manager?: boolean;
  app_role_id?: string | null;
  job_title?: string;
  sex?: string;
  start_date?: string;
  tenant_id: string;
}) {
  const supabase = await createClient();
  const { data: result, error } = await supabase
    .from('employees')
    .insert(data)
    .select()
    .single();

  if (error) {
    console.error('createEmployee error:', error);
    return { success: false, error: error.message };
  }
  revalidatePath(`${ADM_PATH}/employees`);
  revalidatePath(`${ADM_PATH}/divisions`);
  return { success: true, data: result };
}

export async function updateEmployee(id: string, updates: {
  name?: string;
  employee_no?: string;
  division_id?: string | null;
  active_status?: string;
  is_manager?: boolean;
  app_role_id?: string | null;
  job_title?: string;
  sex?: string;
  start_date?: string;
}) {
  const supabase = await createClient();
  const { data: result, error } = await supabase
    .from('employees')
    .update(updates)
    .eq('id', id)
    .select()
    .single();

  if (error) {
    console.error('updateEmployee error:', error);
    return { success: false, error: error.message };
  }
  revalidatePath(`${ADM_PATH}/employees`);
  revalidatePath(`${ADM_PATH}/divisions`);
  return { success: true, data: result };
}

export async function deleteEmployee(id: string) {
  const supabase = await createClient();
  const { error } = await supabase
    .from('employees')
    .delete()
    .eq('id', id);

  if (error) {
    console.error('deleteEmployee error:', error);
    return { success: false, error: error.message };
  }
  revalidatePath(`${ADM_PATH}/employees`);
  revalidatePath(`${ADM_PATH}/divisions`);
  return { success: true };
}

// =====================================================
// 所属変更（割当・異動）
// =====================================================

export async function assignEmployeeToDivision(
  employeeId: string,
  divisionId: string | null
) {
  const supabase = await createClient();
  const { error } = await supabase
    .from('employees')
    .update({ division_id: divisionId })
    .eq('id', employeeId);

  if (error) {
    console.error('assignEmployeeToDivision error:', error);
    return { success: false, error: error.message };
  }
  revalidatePath(`${ADM_PATH}/divisions`);
  revalidatePath(`${ADM_PATH}/employees`);
  return { success: true };
}
