import { createClient } from "@/lib/supabase/server";
import { AppUser } from "@/types/auth";

export async function getServerUser(): Promise<AppUser | null> {
  const supabase = await createClient();
  const { data: { user } } = await supabase.auth.getUser();

  if (!user) return null;

  let name = user.user_metadata?.name || "Guest User";
  const role = user.user_metadata?.role || "member";
  let tenant_id = user.user_metadata?.tenant_id;
  let tenant_name = undefined;
  let appRole = undefined;

  // fetch employee details, app_role, and tenant_name from db if available
  const { data: employee } = await supabase
    .from('employees')
    .select(`
      name,
      tenant_id,
      app_role:app_role_id(app_role),
      tenants:tenant_id(name)
    `)
    .eq('user_id', user.id)
    .single();

  if (employee) {
    if (employee.name) name = employee.name;
    if (employee.tenant_id) tenant_id = employee.tenant_id;
    
    const distinctRole = employee.app_role as { app_role?: string } | null | undefined;
    if (distinctRole?.app_role) {
      appRole = distinctRole.app_role;
    }

    const tenantInfo = employee.tenants as { name?: string } | null | undefined;
    if (tenantInfo?.name) {
      tenant_name = tenantInfo.name;
    }
  }

  // If we couldn't get tenant_name via employee, try fetching directly if tenant_id exists
  if (tenant_id && !tenant_name) {
    const { data: tenant } = await supabase
      .from('tenants')
      .select('name')
      .eq('id', tenant_id)
      .single();
    if (tenant) {
      tenant_name = tenant.name;
    }
  }

  return {
    id: user.id,
    email: user.email,
    name,
    role,
    appRole,
    tenant_id,
    tenant_name,
  };
}
