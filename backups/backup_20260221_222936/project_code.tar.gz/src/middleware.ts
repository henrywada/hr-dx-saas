import { type NextRequest, NextResponse, type NextFetchEvent } from 'next/server'
import { updateSession } from '@/lib/supabase/middleware'
import { APP_ROUTES } from '@/config/routes'

export async function middleware(request: NextRequest, event: NextFetchEvent) {
  // Supabase セッション更新とUser情報の取得 (Edge Runtime)
  const { response, user, supabase } = await updateSession(request)

  const pathname = request.nextUrl.pathname
  const isAuthPage = pathname.startsWith(APP_ROUTES.AUTH.LOGIN) || pathname.startsWith('/reset-password') || pathname.startsWith('/api/auth')
  const isPublicPage = pathname === '/'

  // アクセスログの記録（Edge Runtime上でレスポンスをブロックせずに非同期実行）
  if (!pathname.startsWith('/_next') && !pathname.includes('.')) {
    const insertLog = async () => {
      let tenant_id = user?.user_metadata?.tenant_id || null;
      
      // user_metadata に tenant_id が無い場合（大半の従業員用）、employees テーブルから裏で非同期補完
      if (!tenant_id && user?.id) {
        // eslint-disable-next-line @typescript-eslint/no-explicit-any
        const { data } = await supabase.from('employees' as any).select('tenant_id').eq('user_id', user.id).single();
        // eslint-disable-next-line @typescript-eslint/no-explicit-any
        const emp = data as any;
        if (emp?.tenant_id) {
          tenant_id = emp.tenant_id;
        }
      }

      // eslint-disable-next-line @typescript-eslint/no-explicit-any
      await supabase.from('access_logs' as any).insert({
        action: 'PAGE_VIEW',
        path: pathname,
        method: request.method,
        ip_address: request.headers.get('x-forwarded-for') || null,
        user_agent: request.headers.get('user-agent') || null,
        tenant_id: tenant_id,
        user_id: user?.id || null,
        details: {
          search_params: Object.fromEntries(request.nextUrl.searchParams)
        }
      });
    };
    // event.waitUntil を使うことで、ユーザーへの画面返却を待たせずに裏でログをDBへ書き込ませる
    event.waitUntil(insertLog());
  }

  // 未認証ユーザーが保護されたページにアクセス
  if (!user && !isAuthPage && !isPublicPage) {
    return NextResponse.redirect(new URL(APP_ROUTES.AUTH.LOGIN, request.url))
  }

  // 認証済みユーザーのルーティング
  if (user) {
    // パスワード設定ページはリカバリーフロー中なのでリダイレクトしない
    const isResetPassword = pathname.startsWith('/reset-password')
    // ログイン済みユーザーがログインページ等にアクセスした場合はTOPへ（パスワード設定を除く）
    if ((isAuthPage || isPublicPage) && !isResetPassword) {
      return NextResponse.redirect(new URL(APP_ROUTES.TENANT.PORTAL, request.url))
    }
  }

  return response
}

export const config = {
  matcher: [
    '/((?!_next/static|_next/image|favicon.ico|.*\\.(?:svg|png|jpg|jpeg|gif|webp)$).*)',
  ],
}