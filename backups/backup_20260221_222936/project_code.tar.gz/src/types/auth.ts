export interface AppUser {
  id: string;
  email?: string;
  name: string;
  role: string;
  appRole?: string;
  tenant_id?: string;
  tenant_name?: string;
}

export interface AuthSession {
  user: AppUser;
  expires?: string;
}