pg_dump: warning: there are circular foreign-key constraints on this table:
pg_dump: detail: divisions
pg_dump: hint: You might not be able to restore the dump without using --disable-triggers or temporarily dropping the constraints.
pg_dump: hint: Consider using a full dump instead of a --data-only dump to avoid this problem.
--
-- PostgreSQL database dump
--

\restrict 9A1LPLcTETwpfuya0AsgP8LfkHL6dFjm8owJn7lrF2N44qmzc0S5T3WTJvfSx7O

-- Dumped from database version 17.6
-- Dumped by pg_dump version 17.6

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Data for Name: app_role; Type: TABLE DATA; Schema: public; Owner: supabase_admin
--

COPY public.app_role (id, app_role, name) FROM stdin;
10000000-0000-0000-0000-000000000001	employee	従業員
10000000-0000-0000-0000-000000000002	hr_manager	人事マネージャー
\.


--
-- Data for Name: service_category; Type: TABLE DATA; Schema: public; Owner: supabase_admin
--

COPY public.service_category (id, sort_order, name, description, release_status) FROM stdin;
20000000-0000-0000-0000-000000000001	1	基本	基本サービス	released
\.


--
-- Data for Name: service; Type: TABLE DATA; Schema: public; Owner: supabase_admin
--

COPY public.service (id, service_category_id, name, category, title, description, sort_order, route_path, app_role_group_id, app_role_group_uuid, target_audience, release_status) FROM stdin;
30000000-0000-0000-0000-000000000001	20000000-0000-0000-0000-000000000001	hr-agent	hr	HR Agent	HR支援	1	/hr-agent	\N	\N	all_users	released
82ec9e67-a151-4cf6-8092-d71cdf9fd265	\N	SHOULD_FAIL	\N	\N	\N	\N	\N	\N	\N	\N	\N
\.


--
-- Data for Name: app_role_service; Type: TABLE DATA; Schema: public; Owner: supabase_admin
--

COPY public.app_role_service (id, app_role_id, service_id) FROM stdin;
\.


--
-- Data for Name: tenants; Type: TABLE DATA; Schema: public; Owner: supabase_admin
--

COPY public.tenants (id, name, contact_date, paid_amount, employee_count, paid_date, created_at) FROM stdin;
11111111-1111-1111-1111-111111111111	Tenant A	\N	\N	\N	\N	2026-02-13 10:41:30.020372+00
22222222-2222-2222-2222-222222222222	Tenant B	\N	\N	\N	\N	2026-02-13 10:41:30.020372+00
\.


--
-- Data for Name: divisions; Type: TABLE DATA; Schema: public; Owner: supabase_admin
--

COPY public.divisions (id, tenant_id, name, parent_id, layer, code) FROM stdin;
\.


--
-- Data for Name: employees; Type: TABLE DATA; Schema: public; Owner: supabase_admin
--

COPY public.employees (id, tenant_id, division_id, active_status, name, is_manager, app_role_id, employee_no, job_title, sex, start_date, is_contacted_person, contacted_date, user_id) FROM stdin;
e1111111-1111-1111-1111-111111111111	11111111-1111-1111-1111-111111111111	\N	active	A太郎	t	10000000-0000-0000-0000-000000000002	A-001	HR	M	2024-01-01	t	2024-01-02	610ac6ac-395b-436a-b7f3-8a6d83cb073c
e2222222-2222-2222-2222-222222222222	22222222-2222-2222-2222-222222222222	\N	active	B花子	f	10000000-0000-0000-0000-000000000001	B-001	Sales	F	2024-01-01	f	\N	467befb4-ee25-433c-be40-886ba3871d97
\.


--
-- Data for Name: tenant_service; Type: TABLE DATA; Schema: public; Owner: supabase_admin
--

COPY public.tenant_service (id, tenant_id, service_id, start_date, status) FROM stdin;
c594d583-39ed-4906-9c92-2c6d5412d8fd	11111111-1111-1111-1111-111111111111	30000000-0000-0000-0000-000000000001	2024-01-01	active
cd76fe3a-1014-4c73-9990-2ca7408a373c	22222222-2222-2222-2222-222222222222	30000000-0000-0000-0000-000000000001	2024-01-01	active
40000000-0000-0000-0000-000000000001	11111111-1111-1111-1111-111111111111	30000000-0000-0000-0000-000000000001	2024-01-01	active
40000000-0000-0000-0000-000000000002	22222222-2222-2222-2222-222222222222	30000000-0000-0000-0000-000000000001	2024-01-01	active
\.


--
-- PostgreSQL database dump complete
--

\unrestrict 9A1LPLcTETwpfuya0AsgP8LfkHL6dFjm8owJn7lrF2N44qmzc0S5T3WTJvfSx7O

