--
-- PostgreSQL database dump
--

\restrict j6CpFZ8eOUZrUwX1mK6S8UymE8EEy3KxGIV54pUejdPP1O8E7Dhbs7Hw14NeLUH

-- Dumped from database version 17.6
-- Dumped by pg_dump version 17.6

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: public; Type: SCHEMA; Schema: -; Owner: pg_database_owner
--

CREATE SCHEMA public;


ALTER SCHEMA public OWNER TO pg_database_owner;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: pg_database_owner
--

COMMENT ON SCHEMA public IS 'standard public schema';


--
-- Name: current_tenant_id(); Type: FUNCTION; Schema: public; Owner: supabase_admin
--

CREATE FUNCTION public.current_tenant_id() RETURNS uuid
    LANGUAGE sql STABLE SECURITY DEFINER
    SET search_path TO 'public'
    AS $$
  select e.tenant_id
  from public.employees e
  where e.user_id = auth.uid()
  limit 1
$$;


ALTER FUNCTION public.current_tenant_id() OWNER TO supabase_admin;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: app_role; Type: TABLE; Schema: public; Owner: supabase_admin
--

CREATE TABLE public.app_role (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    app_role text,
    name text
);


ALTER TABLE public.app_role OWNER TO supabase_admin;

--
-- Name: app_role_service; Type: TABLE; Schema: public; Owner: supabase_admin
--

CREATE TABLE public.app_role_service (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    app_role_id uuid,
    service_id uuid
);


ALTER TABLE public.app_role_service OWNER TO supabase_admin;

--
-- Name: divisions; Type: TABLE; Schema: public; Owner: supabase_admin
--

CREATE TABLE public.divisions (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id uuid,
    name text,
    parent_id uuid,
    layer integer,
    code text
);


ALTER TABLE public.divisions OWNER TO supabase_admin;

--
-- Name: employees; Type: TABLE; Schema: public; Owner: supabase_admin
--

CREATE TABLE public.employees (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id uuid,
    division_id uuid,
    active_status text,
    name text,
    is_manager boolean,
    app_role_id uuid,
    employee_no text,
    job_title text,
    sex text,
    start_date date,
    is_contacted_person boolean,
    contacted_date date,
    user_id uuid
);


ALTER TABLE public.employees OWNER TO supabase_admin;

--
-- Name: service; Type: TABLE; Schema: public; Owner: supabase_admin
--

CREATE TABLE public.service (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    service_category_id uuid,
    name text,
    category text,
    title text,
    description text,
    sort_order integer,
    route_path text,
    app_role_group_id uuid,
    app_role_group_uuid uuid,
    target_audience text,
    release_status text
);


ALTER TABLE public.service OWNER TO supabase_admin;

--
-- Name: service_category; Type: TABLE; Schema: public; Owner: supabase_admin
--

CREATE TABLE public.service_category (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    sort_order integer,
    name text,
    description text,
    release_status text
);


ALTER TABLE public.service_category OWNER TO supabase_admin;

--
-- Name: tenant_service; Type: TABLE; Schema: public; Owner: supabase_admin
--

CREATE TABLE public.tenant_service (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id uuid,
    service_id uuid,
    start_date date,
    status text
);


ALTER TABLE public.tenant_service OWNER TO supabase_admin;

--
-- Name: tenants; Type: TABLE; Schema: public; Owner: supabase_admin
--

CREATE TABLE public.tenants (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    name text,
    contact_date date,
    paid_amount integer,
    employee_count integer,
    paid_date date,
    created_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.tenants OWNER TO supabase_admin;

--
-- Data for Name: app_role; Type: TABLE DATA; Schema: public; Owner: supabase_admin
--

COPY public.app_role (id, app_role, name) FROM stdin;
10000000-0000-0000-0000-000000000001	employee	従業員
10000000-0000-0000-0000-000000000002	hr_manager	人事マネージャー
\.


--
-- Data for Name: app_role_service; Type: TABLE DATA; Schema: public; Owner: supabase_admin
--

COPY public.app_role_service (id, app_role_id, service_id) FROM stdin;
\.


--
-- Data for Name: divisions; Type: TABLE DATA; Schema: public; Owner: supabase_admin
--

COPY public.divisions (id, tenant_id, name, parent_id, layer, code) FROM stdin;
\.


--
-- Data for Name: employees; Type: TABLE DATA; Schema: public; Owner: supabase_admin
--

COPY public.employees (id, tenant_id, division_id, active_status, name, is_manager, app_role_id, employee_no, job_title, sex, start_date, is_contacted_person, contacted_date, user_id) FROM stdin;
e1111111-1111-1111-1111-111111111111	11111111-1111-1111-1111-111111111111	\N	active	A太郎	t	10000000-0000-0000-0000-000000000002	A-001	HR	M	2024-01-01	t	2024-01-02	610ac6ac-395b-436a-b7f3-8a6d83cb073c
e2222222-2222-2222-2222-222222222222	22222222-2222-2222-2222-222222222222	\N	active	B花子	f	10000000-0000-0000-0000-000000000001	B-001	Sales	F	2024-01-01	f	\N	467befb4-ee25-433c-be40-886ba3871d97
\.


--
-- Data for Name: service; Type: TABLE DATA; Schema: public; Owner: supabase_admin
--

COPY public.service (id, service_category_id, name, category, title, description, sort_order, route_path, app_role_group_id, app_role_group_uuid, target_audience, release_status) FROM stdin;
30000000-0000-0000-0000-000000000001	20000000-0000-0000-0000-000000000001	hr-agent	hr	HR Agent	HR支援	1	/hr-agent	\N	\N	all_users	released
82ec9e67-a151-4cf6-8092-d71cdf9fd265	\N	SHOULD_FAIL	\N	\N	\N	\N	\N	\N	\N	\N	\N
\.


--
-- Data for Name: service_category; Type: TABLE DATA; Schema: public; Owner: supabase_admin
--

COPY public.service_category (id, sort_order, name, description, release_status) FROM stdin;
20000000-0000-0000-0000-000000000001	1	基本	基本サービス	released
\.


--
-- Data for Name: tenant_service; Type: TABLE DATA; Schema: public; Owner: supabase_admin
--

COPY public.tenant_service (id, tenant_id, service_id, start_date, status) FROM stdin;
c594d583-39ed-4906-9c92-2c6d5412d8fd	11111111-1111-1111-1111-111111111111	30000000-0000-0000-0000-000000000001	2024-01-01	active
cd76fe3a-1014-4c73-9990-2ca7408a373c	22222222-2222-2222-2222-222222222222	30000000-0000-0000-0000-000000000001	2024-01-01	active
40000000-0000-0000-0000-000000000001	11111111-1111-1111-1111-111111111111	30000000-0000-0000-0000-000000000001	2024-01-01	active
40000000-0000-0000-0000-000000000002	22222222-2222-2222-2222-222222222222	30000000-0000-0000-0000-000000000001	2024-01-01	active
\.


--
-- Data for Name: tenants; Type: TABLE DATA; Schema: public; Owner: supabase_admin
--

COPY public.tenants (id, name, contact_date, paid_amount, employee_count, paid_date, created_at) FROM stdin;
11111111-1111-1111-1111-111111111111	Tenant A	\N	\N	\N	\N	2026-02-13 10:41:30.020372+00
22222222-2222-2222-2222-222222222222	Tenant B	\N	\N	\N	\N	2026-02-13 10:41:30.020372+00
\.


--
-- Name: app_role app_role_pkey; Type: CONSTRAINT; Schema: public; Owner: supabase_admin
--

ALTER TABLE ONLY public.app_role
    ADD CONSTRAINT app_role_pkey PRIMARY KEY (id);


--
-- Name: app_role_service app_role_service_pkey; Type: CONSTRAINT; Schema: public; Owner: supabase_admin
--

ALTER TABLE ONLY public.app_role_service
    ADD CONSTRAINT app_role_service_pkey PRIMARY KEY (id);


--
-- Name: divisions divisions_pkey; Type: CONSTRAINT; Schema: public; Owner: supabase_admin
--

ALTER TABLE ONLY public.divisions
    ADD CONSTRAINT divisions_pkey PRIMARY KEY (id);


--
-- Name: employees employees_pkey; Type: CONSTRAINT; Schema: public; Owner: supabase_admin
--

ALTER TABLE ONLY public.employees
    ADD CONSTRAINT employees_pkey PRIMARY KEY (id);


--
-- Name: service_category service_category_pkey; Type: CONSTRAINT; Schema: public; Owner: supabase_admin
--

ALTER TABLE ONLY public.service_category
    ADD CONSTRAINT service_category_pkey PRIMARY KEY (id);


--
-- Name: service service_pkey; Type: CONSTRAINT; Schema: public; Owner: supabase_admin
--

ALTER TABLE ONLY public.service
    ADD CONSTRAINT service_pkey PRIMARY KEY (id);


--
-- Name: tenant_service tenant_service_pkey; Type: CONSTRAINT; Schema: public; Owner: supabase_admin
--

ALTER TABLE ONLY public.tenant_service
    ADD CONSTRAINT tenant_service_pkey PRIMARY KEY (id);


--
-- Name: tenants tenants_pkey; Type: CONSTRAINT; Schema: public; Owner: supabase_admin
--

ALTER TABLE ONLY public.tenants
    ADD CONSTRAINT tenants_pkey PRIMARY KEY (id);


--
-- Name: app_role_service app_role_service_app_role_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: supabase_admin
--

ALTER TABLE ONLY public.app_role_service
    ADD CONSTRAINT app_role_service_app_role_id_fkey FOREIGN KEY (app_role_id) REFERENCES public.app_role(id) ON DELETE CASCADE;


--
-- Name: app_role_service app_role_service_service_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: supabase_admin
--

ALTER TABLE ONLY public.app_role_service
    ADD CONSTRAINT app_role_service_service_id_fkey FOREIGN KEY (service_id) REFERENCES public.service(id) ON DELETE CASCADE;


--
-- Name: divisions divisions_parent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: supabase_admin
--

ALTER TABLE ONLY public.divisions
    ADD CONSTRAINT divisions_parent_id_fkey FOREIGN KEY (parent_id) REFERENCES public.divisions(id) ON DELETE SET NULL;


--
-- Name: divisions divisions_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: supabase_admin
--

ALTER TABLE ONLY public.divisions
    ADD CONSTRAINT divisions_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: employees employees_app_role_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: supabase_admin
--

ALTER TABLE ONLY public.employees
    ADD CONSTRAINT employees_app_role_id_fkey FOREIGN KEY (app_role_id) REFERENCES public.app_role(id) ON DELETE SET NULL;


--
-- Name: employees employees_division_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: supabase_admin
--

ALTER TABLE ONLY public.employees
    ADD CONSTRAINT employees_division_id_fkey FOREIGN KEY (division_id) REFERENCES public.divisions(id) ON DELETE SET NULL;


--
-- Name: employees employees_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: supabase_admin
--

ALTER TABLE ONLY public.employees
    ADD CONSTRAINT employees_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: employees employees_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: supabase_admin
--

ALTER TABLE ONLY public.employees
    ADD CONSTRAINT employees_user_id_fkey FOREIGN KEY (user_id) REFERENCES auth.users(id) ON DELETE SET NULL;


--
-- Name: service service_service_category_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: supabase_admin
--

ALTER TABLE ONLY public.service
    ADD CONSTRAINT service_service_category_id_fkey FOREIGN KEY (service_category_id) REFERENCES public.service_category(id) ON DELETE SET NULL;


--
-- Name: tenant_service tenant_service_service_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: supabase_admin
--

ALTER TABLE ONLY public.tenant_service
    ADD CONSTRAINT tenant_service_service_id_fkey FOREIGN KEY (service_id) REFERENCES public.service(id) ON DELETE CASCADE;


--
-- Name: tenant_service tenant_service_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: supabase_admin
--

ALTER TABLE ONLY public.tenant_service
    ADD CONSTRAINT tenant_service_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: app_role; Type: ROW SECURITY; Schema: public; Owner: supabase_admin
--

ALTER TABLE public.app_role ENABLE ROW LEVEL SECURITY;

--
-- Name: app_role_service; Type: ROW SECURITY; Schema: public; Owner: supabase_admin
--

ALTER TABLE public.app_role_service ENABLE ROW LEVEL SECURITY;

--
-- Name: divisions; Type: ROW SECURITY; Schema: public; Owner: supabase_admin
--

ALTER TABLE public.divisions ENABLE ROW LEVEL SECURITY;

--
-- Name: divisions divisions_delete_same_tenant; Type: POLICY; Schema: public; Owner: supabase_admin
--

CREATE POLICY divisions_delete_same_tenant ON public.divisions FOR DELETE USING ((tenant_id = public.current_tenant_id()));


--
-- Name: divisions divisions_insert_same_tenant; Type: POLICY; Schema: public; Owner: supabase_admin
--

CREATE POLICY divisions_insert_same_tenant ON public.divisions FOR INSERT WITH CHECK ((tenant_id = public.current_tenant_id()));


--
-- Name: divisions divisions_select_same_tenant; Type: POLICY; Schema: public; Owner: supabase_admin
--

CREATE POLICY divisions_select_same_tenant ON public.divisions FOR SELECT USING ((tenant_id = public.current_tenant_id()));


--
-- Name: divisions divisions_update_same_tenant; Type: POLICY; Schema: public; Owner: supabase_admin
--

CREATE POLICY divisions_update_same_tenant ON public.divisions FOR UPDATE USING ((tenant_id = public.current_tenant_id())) WITH CHECK ((tenant_id = public.current_tenant_id()));


--
-- Name: employees; Type: ROW SECURITY; Schema: public; Owner: supabase_admin
--

ALTER TABLE public.employees ENABLE ROW LEVEL SECURITY;

--
-- Name: employees employees_delete_same_tenant; Type: POLICY; Schema: public; Owner: supabase_admin
--

CREATE POLICY employees_delete_same_tenant ON public.employees FOR DELETE USING ((tenant_id = public.current_tenant_id()));


--
-- Name: employees employees_insert_same_tenant; Type: POLICY; Schema: public; Owner: supabase_admin
--

CREATE POLICY employees_insert_same_tenant ON public.employees FOR INSERT WITH CHECK ((tenant_id = public.current_tenant_id()));


--
-- Name: employees employees_select_same_tenant; Type: POLICY; Schema: public; Owner: supabase_admin
--

CREATE POLICY employees_select_same_tenant ON public.employees FOR SELECT USING ((tenant_id = public.current_tenant_id()));


--
-- Name: employees employees_update_same_tenant; Type: POLICY; Schema: public; Owner: supabase_admin
--

CREATE POLICY employees_update_same_tenant ON public.employees FOR UPDATE USING ((tenant_id = public.current_tenant_id())) WITH CHECK ((tenant_id = public.current_tenant_id()));


--
-- Name: app_role global_select_app_role; Type: POLICY; Schema: public; Owner: supabase_admin
--

CREATE POLICY global_select_app_role ON public.app_role FOR SELECT USING ((auth.role() = 'authenticated'::text));


--
-- Name: app_role_service global_select_app_role_service; Type: POLICY; Schema: public; Owner: supabase_admin
--

CREATE POLICY global_select_app_role_service ON public.app_role_service FOR SELECT USING ((auth.role() = 'authenticated'::text));


--
-- Name: service global_select_service; Type: POLICY; Schema: public; Owner: supabase_admin
--

CREATE POLICY global_select_service ON public.service FOR SELECT USING ((auth.role() = 'authenticated'::text));


--
-- Name: service_category global_select_service_category; Type: POLICY; Schema: public; Owner: supabase_admin
--

CREATE POLICY global_select_service_category ON public.service_category FOR SELECT USING ((auth.role() = 'authenticated'::text));


--
-- Name: app_role global_write_app_role; Type: POLICY; Schema: public; Owner: supabase_admin
--

CREATE POLICY global_write_app_role ON public.app_role USING ((auth.role() = 'service_role'::text)) WITH CHECK ((auth.role() = 'service_role'::text));


--
-- Name: app_role_service global_write_app_role_service; Type: POLICY; Schema: public; Owner: supabase_admin
--

CREATE POLICY global_write_app_role_service ON public.app_role_service USING ((auth.role() = 'service_role'::text)) WITH CHECK ((auth.role() = 'service_role'::text));


--
-- Name: service global_write_service; Type: POLICY; Schema: public; Owner: supabase_admin
--

CREATE POLICY global_write_service ON public.service USING ((auth.role() = 'service_role'::text)) WITH CHECK ((auth.role() = 'service_role'::text));


--
-- Name: service_category global_write_service_category; Type: POLICY; Schema: public; Owner: supabase_admin
--

CREATE POLICY global_write_service_category ON public.service_category USING ((auth.role() = 'service_role'::text)) WITH CHECK ((auth.role() = 'service_role'::text));


--
-- Name: service; Type: ROW SECURITY; Schema: public; Owner: supabase_admin
--

ALTER TABLE public.service ENABLE ROW LEVEL SECURITY;

--
-- Name: service_category; Type: ROW SECURITY; Schema: public; Owner: supabase_admin
--

ALTER TABLE public.service_category ENABLE ROW LEVEL SECURITY;

--
-- Name: divisions supa_divisions_all; Type: POLICY; Schema: public; Owner: supabase_admin
--

CREATE POLICY supa_divisions_all ON public.divisions USING ((auth.uid() = 'e97488f9-02be-4b0b-9dc9-ddb0c2902999'::uuid)) WITH CHECK ((auth.uid() = 'e97488f9-02be-4b0b-9dc9-ddb0c2902999'::uuid));


--
-- Name: employees supa_employees_all; Type: POLICY; Schema: public; Owner: supabase_admin
--

CREATE POLICY supa_employees_all ON public.employees USING ((auth.uid() = 'e97488f9-02be-4b0b-9dc9-ddb0c2902999'::uuid)) WITH CHECK ((auth.uid() = 'e97488f9-02be-4b0b-9dc9-ddb0c2902999'::uuid));


--
-- Name: tenant_service supa_tenant_service_all; Type: POLICY; Schema: public; Owner: supabase_admin
--

CREATE POLICY supa_tenant_service_all ON public.tenant_service USING ((auth.uid() = 'e97488f9-02be-4b0b-9dc9-ddb0c2902999'::uuid)) WITH CHECK ((auth.uid() = 'e97488f9-02be-4b0b-9dc9-ddb0c2902999'::uuid));


--
-- Name: tenants supa_tenants_all; Type: POLICY; Schema: public; Owner: supabase_admin
--

CREATE POLICY supa_tenants_all ON public.tenants USING ((auth.uid() = 'e97488f9-02be-4b0b-9dc9-ddb0c2902999'::uuid)) WITH CHECK ((auth.uid() = 'e97488f9-02be-4b0b-9dc9-ddb0c2902999'::uuid));


--
-- Name: app_role supa_write_app_role; Type: POLICY; Schema: public; Owner: supabase_admin
--

CREATE POLICY supa_write_app_role ON public.app_role USING ((auth.uid() = 'e97488f9-02be-4b0b-9dc9-ddb0c2902999'::uuid)) WITH CHECK ((auth.uid() = 'e97488f9-02be-4b0b-9dc9-ddb0c2902999'::uuid));


--
-- Name: app_role_service supa_write_app_role_service; Type: POLICY; Schema: public; Owner: supabase_admin
--

CREATE POLICY supa_write_app_role_service ON public.app_role_service USING ((auth.uid() = 'e97488f9-02be-4b0b-9dc9-ddb0c2902999'::uuid)) WITH CHECK ((auth.uid() = 'e97488f9-02be-4b0b-9dc9-ddb0c2902999'::uuid));


--
-- Name: service supa_write_service; Type: POLICY; Schema: public; Owner: supabase_admin
--

CREATE POLICY supa_write_service ON public.service USING ((auth.uid() = 'e97488f9-02be-4b0b-9dc9-ddb0c2902999'::uuid)) WITH CHECK ((auth.uid() = 'e97488f9-02be-4b0b-9dc9-ddb0c2902999'::uuid));


--
-- Name: service_category supa_write_service_category; Type: POLICY; Schema: public; Owner: supabase_admin
--

CREATE POLICY supa_write_service_category ON public.service_category USING ((auth.uid() = 'e97488f9-02be-4b0b-9dc9-ddb0c2902999'::uuid)) WITH CHECK ((auth.uid() = 'e97488f9-02be-4b0b-9dc9-ddb0c2902999'::uuid));


--
-- Name: tenant_service; Type: ROW SECURITY; Schema: public; Owner: supabase_admin
--

ALTER TABLE public.tenant_service ENABLE ROW LEVEL SECURITY;

--
-- Name: tenant_service tenant_service_delete_same_tenant; Type: POLICY; Schema: public; Owner: supabase_admin
--

CREATE POLICY tenant_service_delete_same_tenant ON public.tenant_service FOR DELETE USING ((tenant_id = public.current_tenant_id()));


--
-- Name: tenant_service tenant_service_insert_same_tenant; Type: POLICY; Schema: public; Owner: supabase_admin
--

CREATE POLICY tenant_service_insert_same_tenant ON public.tenant_service FOR INSERT WITH CHECK ((tenant_id = public.current_tenant_id()));


--
-- Name: tenant_service tenant_service_select_same_tenant; Type: POLICY; Schema: public; Owner: supabase_admin
--

CREATE POLICY tenant_service_select_same_tenant ON public.tenant_service FOR SELECT USING ((tenant_id = public.current_tenant_id()));


--
-- Name: tenant_service tenant_service_update_same_tenant; Type: POLICY; Schema: public; Owner: supabase_admin
--

CREATE POLICY tenant_service_update_same_tenant ON public.tenant_service FOR UPDATE USING ((tenant_id = public.current_tenant_id())) WITH CHECK ((tenant_id = public.current_tenant_id()));


--
-- Name: tenants; Type: ROW SECURITY; Schema: public; Owner: supabase_admin
--

ALTER TABLE public.tenants ENABLE ROW LEVEL SECURITY;

--
-- Name: tenants tenants_select_same_tenant; Type: POLICY; Schema: public; Owner: supabase_admin
--

CREATE POLICY tenants_select_same_tenant ON public.tenants FOR SELECT USING ((id = public.current_tenant_id()));


--
-- Name: tenants tenants_update_same_tenant; Type: POLICY; Schema: public; Owner: supabase_admin
--

CREATE POLICY tenants_update_same_tenant ON public.tenants FOR UPDATE USING ((id = public.current_tenant_id())) WITH CHECK ((id = public.current_tenant_id()));


--
-- Name: SCHEMA public; Type: ACL; Schema: -; Owner: pg_database_owner
--

GRANT USAGE ON SCHEMA public TO postgres;
GRANT USAGE ON SCHEMA public TO anon;
GRANT USAGE ON SCHEMA public TO authenticated;
GRANT USAGE ON SCHEMA public TO service_role;


--
-- Name: FUNCTION current_tenant_id(); Type: ACL; Schema: public; Owner: supabase_admin
--

GRANT ALL ON FUNCTION public.current_tenant_id() TO postgres;
GRANT ALL ON FUNCTION public.current_tenant_id() TO anon;
GRANT ALL ON FUNCTION public.current_tenant_id() TO authenticated;
GRANT ALL ON FUNCTION public.current_tenant_id() TO service_role;


--
-- Name: TABLE app_role; Type: ACL; Schema: public; Owner: supabase_admin
--

GRANT ALL ON TABLE public.app_role TO postgres;
GRANT ALL ON TABLE public.app_role TO anon;
GRANT ALL ON TABLE public.app_role TO authenticated;
GRANT ALL ON TABLE public.app_role TO service_role;


--
-- Name: TABLE app_role_service; Type: ACL; Schema: public; Owner: supabase_admin
--

GRANT ALL ON TABLE public.app_role_service TO postgres;
GRANT ALL ON TABLE public.app_role_service TO anon;
GRANT ALL ON TABLE public.app_role_service TO authenticated;
GRANT ALL ON TABLE public.app_role_service TO service_role;


--
-- Name: TABLE divisions; Type: ACL; Schema: public; Owner: supabase_admin
--

GRANT ALL ON TABLE public.divisions TO postgres;
GRANT ALL ON TABLE public.divisions TO anon;
GRANT ALL ON TABLE public.divisions TO authenticated;
GRANT ALL ON TABLE public.divisions TO service_role;


--
-- Name: TABLE employees; Type: ACL; Schema: public; Owner: supabase_admin
--

GRANT ALL ON TABLE public.employees TO postgres;
GRANT ALL ON TABLE public.employees TO anon;
GRANT ALL ON TABLE public.employees TO authenticated;
GRANT ALL ON TABLE public.employees TO service_role;


--
-- Name: TABLE service; Type: ACL; Schema: public; Owner: supabase_admin
--

GRANT ALL ON TABLE public.service TO postgres;
GRANT ALL ON TABLE public.service TO anon;
GRANT ALL ON TABLE public.service TO authenticated;
GRANT ALL ON TABLE public.service TO service_role;


--
-- Name: TABLE service_category; Type: ACL; Schema: public; Owner: supabase_admin
--

GRANT ALL ON TABLE public.service_category TO postgres;
GRANT ALL ON TABLE public.service_category TO anon;
GRANT ALL ON TABLE public.service_category TO authenticated;
GRANT ALL ON TABLE public.service_category TO service_role;


--
-- Name: TABLE tenant_service; Type: ACL; Schema: public; Owner: supabase_admin
--

GRANT ALL ON TABLE public.tenant_service TO postgres;
GRANT ALL ON TABLE public.tenant_service TO anon;
GRANT ALL ON TABLE public.tenant_service TO authenticated;
GRANT ALL ON TABLE public.tenant_service TO service_role;


--
-- Name: TABLE tenants; Type: ACL; Schema: public; Owner: supabase_admin
--

GRANT ALL ON TABLE public.tenants TO postgres;
GRANT ALL ON TABLE public.tenants TO anon;
GRANT ALL ON TABLE public.tenants TO authenticated;
GRANT ALL ON TABLE public.tenants TO service_role;


--
-- Name: DEFAULT PRIVILEGES FOR SEQUENCES; Type: DEFAULT ACL; Schema: public; Owner: postgres
--

ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA public GRANT ALL ON SEQUENCES TO postgres;
ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA public GRANT ALL ON SEQUENCES TO anon;
ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA public GRANT ALL ON SEQUENCES TO authenticated;
ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA public GRANT ALL ON SEQUENCES TO service_role;


--
-- Name: DEFAULT PRIVILEGES FOR SEQUENCES; Type: DEFAULT ACL; Schema: public; Owner: supabase_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA public GRANT ALL ON SEQUENCES TO postgres;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA public GRANT ALL ON SEQUENCES TO anon;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA public GRANT ALL ON SEQUENCES TO authenticated;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA public GRANT ALL ON SEQUENCES TO service_role;


--
-- Name: DEFAULT PRIVILEGES FOR FUNCTIONS; Type: DEFAULT ACL; Schema: public; Owner: postgres
--

ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA public GRANT ALL ON FUNCTIONS TO postgres;
ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA public GRANT ALL ON FUNCTIONS TO anon;
ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA public GRANT ALL ON FUNCTIONS TO authenticated;
ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA public GRANT ALL ON FUNCTIONS TO service_role;


--
-- Name: DEFAULT PRIVILEGES FOR FUNCTIONS; Type: DEFAULT ACL; Schema: public; Owner: supabase_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA public GRANT ALL ON FUNCTIONS TO postgres;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA public GRANT ALL ON FUNCTIONS TO anon;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA public GRANT ALL ON FUNCTIONS TO authenticated;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA public GRANT ALL ON FUNCTIONS TO service_role;


--
-- Name: DEFAULT PRIVILEGES FOR TABLES; Type: DEFAULT ACL; Schema: public; Owner: postgres
--

ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA public GRANT ALL ON TABLES TO postgres;
ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA public GRANT ALL ON TABLES TO anon;
ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA public GRANT ALL ON TABLES TO authenticated;
ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA public GRANT ALL ON TABLES TO service_role;


--
-- Name: DEFAULT PRIVILEGES FOR TABLES; Type: DEFAULT ACL; Schema: public; Owner: supabase_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA public GRANT ALL ON TABLES TO postgres;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA public GRANT ALL ON TABLES TO anon;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA public GRANT ALL ON TABLES TO authenticated;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA public GRANT ALL ON TABLES TO service_role;


--
-- PostgreSQL database dump complete
--

\unrestrict j6CpFZ8eOUZrUwX1mK6S8UymE8EEy3KxGIV54pUejdPP1O8E7Dhbs7Hw14NeLUH

