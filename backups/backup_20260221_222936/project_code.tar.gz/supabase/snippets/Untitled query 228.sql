CREATE TABLE system_logs (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  tenant_id UUID REFERENCES tenants(id),
  employee_id UUID REFERENCES employees(id),
  action TEXT NOT NULL, -- 'login', 'create_user', 'update_setting' など
  entity_type TEXT,     -- 'employee', 'tenant', 'service'
  description TEXT,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- インデックス作成（集計を高速化するため）
CREATE INDEX idx_logs_created_at ON system_logs(created_at);