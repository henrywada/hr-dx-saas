SELECT column_name 
FROM information_schema.columns 
WHERE table_name = 'app_role_service';