SELECT *
FROM pg_policies
WHERE tablename = 'service';