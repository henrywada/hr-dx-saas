-- 既存の不確実なポリシーを削除
DROP POLICY IF EXISTS "supa_write_service" ON service;

-- 標準的な記述で再作成
CREATE POLICY "supa_write_service_v2"
ON service
FOR ALL
TO authenticated
USING (
  auth.uid() = 'e97488f9-02be-4b0b-9dc9-ddb0c2902999'::uuid
)
WITH CHECK (
  auth.uid() = 'e97488f9-02be-4b0b-9dc9-ddb0c2902999'::uuid
);