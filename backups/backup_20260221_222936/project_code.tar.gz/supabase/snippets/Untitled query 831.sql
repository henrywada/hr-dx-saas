-- 1. アクセスログ（access_logs）テーブルの作成
CREATE TABLE IF NOT EXISTS public.access_logs (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    
    -- 誰がどこ（どの会社）で操作したか
    tenant_id UUID REFERENCES public.tenants(id) ON DELETE CASCADE, -- SaaS管理者のグローバル操作を考慮しNULL許容
    user_id UUID REFERENCES auth.users(id) ON DELETE SET NULL,      -- 退職等でユーザーが消えてもログは残すためSET NULL
    
    -- 何をしたか
    action TEXT NOT NULL,         -- アクション種別（例: 'PAGE_VIEW', 'LOGIN', 'API_CALL', 'DATA_EXPORT'）
    path TEXT NOT NULL,           -- アクセス先のパス（例: '/top', '/adm/hr/users'）
    method TEXT,                  -- HTTPメソッド（'GET', 'POST', 'PUT', 'DELETE'）
    
    -- 環境情報など
    ip_address TEXT,              -- 接続元のIPアドレス
    user_agent TEXT,              -- ブラウザ・OS情報
    details JSONB,                -- 拡張用メタデータ（例: エラー内容、検索クエリ、変更内容の詳細など）
    
    created_at TIMESTAMP WITH TIME ZONE DEFAULT timezone('utc'::text, now()) NOT NULL
);

-- テーブルへのコメント付与（Supabase上で分かりやすくするため）
COMMENT ON TABLE public.access_logs IS 'システム全体のアクセスログおよび監査ログ';

-- 2. パフォーマンス向上のためのインデックス作成
-- ログが肥大化しても検索・ソートが高速になります
CREATE INDEX IF NOT EXISTS access_logs_tenant_id_idx ON public.access_logs(tenant_id);
CREATE INDEX IF NOT EXISTS access_logs_user_id_idx ON public.access_logs(user_id);
CREATE INDEX IF NOT EXISTS access_logs_created_at_idx ON public.access_logs(created_at DESC);

-- 3. RLS (Row Level Security) の有効化
ALTER TABLE public.access_logs ENABLE ROW LEVEL SECURITY;

-- ==============================================================================
-- 4. RLSポリシーの定義
-- ==============================================================================

-- ポリシーを一旦リセット（再実行時のエラー防止のため）
DROP POLICY IF EXISTS "Users can insert their own access logs" ON public.access_logs;
DROP POLICY IF EXISTS "Tenant admins can view their tenant's logs" ON public.access_logs;
DROP POLICY IF EXISTS "SaaS admins can view all access logs" ON public.access_logs;

-- 【INSERT ポリシー】
-- アプリケーション（Next.js側）からログを記録できるようにする制限
-- ※ バックエンドのServer Action等で「service_role」キーを使って強制記録する場合はこのポリシーすら不要ですが、
-- 汎用性を持たせるため「認証済みユーザーは自分自身のIDでログを挿入できる」ようにします。
CREATE POLICY "Users can insert their own access logs"
    ON public.access_logs
    FOR INSERT
    TO authenticated
    WITH CHECK (auth.uid() = user_id);

-- 【SELECT ポリシー ①: テナント管理者用】
-- ログイン中のユーザーが「admin」権限を持っており、かつアクセス先のログが「自身の所属テナント」である場合のみ閲覧可能
CREATE POLICY "Tenant admins can view their tenant's logs"
    ON public.access_logs
    FOR SELECT
    TO authenticated
    USING (
        tenant_id = (auth.jwt() -> 'user_metadata' ->> 'tenant_id')::UUID
        AND (auth.jwt() -> 'user_metadata' ->> 'role') = 'admin'
    );

-- 【SELECT ポリシー ②: SaaS管理者用】
-- ログイン中のユーザーが「supaUser」権限を持っている場合は、テナントの垣根を超えて全てのログを閲覧可能
CREATE POLICY "SaaS admins can view all access logs"
    ON public.access_logs
    FOR SELECT
    TO authenticated
    USING (
        (auth.jwt() -> 'user_metadata' ->> 'role') = 'supaUser'
    );
