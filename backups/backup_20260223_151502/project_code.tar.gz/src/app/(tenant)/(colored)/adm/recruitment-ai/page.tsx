import { getServerUser } from '@/lib/auth/server-user';
import { redirect } from 'next/navigation';
import { APP_ROUTES } from '@/config/routes';
import { AiJobForm } from '@/features/recruitment-ai/components/AiJobForm';

export default async function RecruitmentAiPage() {
  const user = await getServerUser();
  if (!user?.tenant_id) {
    redirect(APP_ROUTES.AUTH.LOGIN);
  }

  return (
    <div className="p-6 max-w-7xl mx-auto">
      <div className="mb-8">
        <h1 className="text-2xl font-bold text-slate-900 tracking-tight">
          TalentDraft AI
        </h1>
        <p className="text-sm text-slate-500 mt-1">
          AIが求人キャッチコピー・スカウト文・面接ガイドを自動生成します
        </p>
      </div>

      <AiJobForm planType={user.planType} />
    </div>
  );
}
