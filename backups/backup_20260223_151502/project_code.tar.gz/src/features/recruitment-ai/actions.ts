'use server';

/**
 * TalentDraft AI — Server Actions
 *
 * OpenAI API (gpt-4o) を使って求人コンテンツを自動生成し、
 * recruitment_jobs テーブルへ保存する。
 */

import { createClient } from '@/lib/supabase/server';
import { getServerUser } from '@/lib/auth/server-user';
import type { AiGenerationResult } from './types';

// ─────────────────────────────────────────────
// 入力フォームの型
// ─────────────────────────────────────────────
export interface GenerateJobInput {
  /** 採用で解決したい課題 */
  challenge: string;
  /** 候補者に期待すること */
  expectations: string;
  /** 自社のユニークな点・魅力 */
  uniquePoints: string;
}

// ─────────────────────────────────────────────
// System Prompt（日本の採用市場に最適化）
// ─────────────────────────────────────────────
const SYSTEM_PROMPT = `あなたは日本の採用市場に精通したプロフェッショナルな採用コピーライターです。
以下のルールを厳守してください：

【コンテンツルール】
- 日本のビジネス慣習・敬語表現を正しく使用すること
- 性別・年齢・国籍・障害等による差別的な表現を絶対に含めないこと（男女雇用機会均等法・職業安定法に準拠）
- 「若手歓迎」「体力のある方」等の間接差別表現も避けること
- 具体的かつ魅力的な表現を心がけ、抽象的・テンプレート的な文言を避けること
- 会社の独自性や成長機会を効果的にアピールすること

【出力形式】
必ず以下の JSON 形式で出力してください。JSON以外のテキストは一切含めないこと。
{
  "catchphrase": "キャッチコピー（100文字以内の魅力的な一文）",
  "scoutText": "スカウト文面（300〜500文字。候補者に直接語りかける丁寧な文体で、入社メリットを具体的に記載）",
  "interviewGuide": "面接質問ガイド（5つの質問と各質問の評価ポイントを箇条書きで記載。構造化面接の観点を取り入れること）"
}`;

// ─────────────────────────────────────────────
// generateJobContent — AI求人コンテンツ生成
// ─────────────────────────────────────────────
export async function generateJobContent(
  input: GenerateJobInput
): Promise<{ success: boolean; data?: AiGenerationResult; error?: string }> {
  try {
    // 1. 認証チェック
    const user = await getServerUser();
    if (!user || !user.tenant_id) {
      return { success: false, error: '認証されていません。ログインしてください。' };
    }

    // 1.5 プラン・利用回数チェック
    const usage = await getMonthlyUsageCount();
    if (!usage.isUnlimited && usage.count >= usage.max) {
      return { success: false, error: '今月のAI無料利用チケット（10回）の上限に達しました。無制限でご利用いただくにはProプランへのアップグレードをご検討ください。' };
    }

    // 2. OpenAI API キー確認
    const apiKey = process.env.OPENAI_API_KEY;
    if (!apiKey || apiKey.includes('xxxxxxxx')) {
      return { success: false, error: 'OpenAI API キーが設定されていません。管理者にお問い合わせください。' };
    }

    // 3. 入力バリデーション
    if (!input.challenge?.trim() || !input.expectations?.trim() || !input.uniquePoints?.trim()) {
      return { success: false, error: 'すべての質問に回答してください。' };
    }

    // 4. OpenAI API 呼び出し
    const userPrompt = `以下の情報をもとに、求人コンテンツを生成してください。

【採用で解決したい課題】
${input.challenge.trim()}

【候補者に期待すること】
${input.expectations.trim()}

【自社のユニークな点・魅力】
${input.uniquePoints.trim()}`;

    const response = await fetch('https://api.openai.com/v1/chat/completions', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${apiKey}`,
      },
      body: JSON.stringify({
        model: 'gpt-4o',
        messages: [
          { role: 'system', content: SYSTEM_PROMPT },
          { role: 'user', content: userPrompt },
        ],
        temperature: 0.7,
        max_tokens: 2000,
        response_format: { type: 'json_object' },
      }),
    });

    if (!response.ok) {
      const errorText = await response.text();
      console.error('[TalentDraft AI] OpenAI API error:', errorText);
      return { success: false, error: 'AI生成中にエラーが発生しました。しばらくしてからお試しください。' };
    }

    const completion = await response.json();
    const content = completion.choices?.[0]?.message?.content;
    if (!content) {
      return { success: false, error: 'AIからの応答が空でした。' };
    }

    // 5. JSON パース
    let parsed: AiGenerationResult;
    try {
      parsed = JSON.parse(content);
    } catch {
      console.error('[TalentDraft AI] JSON parse error:', content);
      return { success: false, error: 'AI出力の解析に失敗しました。' };
    }

    // 6. コンテンツ生成結果（全プラン共通化：フルオープン）
    const result: AiGenerationResult = {
      catchphrase: parsed.catchphrase || '',
      scoutText: parsed.scoutText || '',
      interviewGuide: parsed.interviewGuide || '',
    };

    // 7. DB に保存
    const supabase = await createClient();
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    const { error: dbError } = await (supabase as any)
      .from('recruitment_jobs')
      .insert({
        tenant_id: user.tenant_id,
        title: parsed.catchphrase?.substring(0, 100) || '未設定',
        description: input.challenge,
        requirements: input.expectations,
        ai_catchphrase: parsed.catchphrase,
        ai_scout_text: parsed.scoutText,
        ai_interview_guide: parsed.interviewGuide,
        created_by: user.id,
        status: '下書き',
      });

    if (dbError) {
      console.error('[TalentDraft AI] DB insert error:', dbError);
      // DB保存失敗でもAI結果は返す
    }
    
    // 8. ai_usage_logs に利用履歴を記録
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    const { error: logError } = await (supabase as any)
      .from('ai_usage_logs')
      .insert({
        tenant_id: user.tenant_id,
        feature_name: 'talent-draft',
      });
      
    if (logError) {
      console.error('[TalentDraft AI] DB insert ai_usage_logs error:', logError);
    }

    return { success: true, data: result };
  } catch (error) {
    console.error('[TalentDraft AI] Unexpected error:', error);
    return { success: false, error: '予期せぬエラーが発生しました。' };
  }
}

// ─────────────────────────────────────────────
// getMonthlyUsageCount — 今月の利用回数取得
// ─────────────────────────────────────────────
export async function getMonthlyUsageCount(): Promise<{
  count: number;
  max: number;
  isUnlimited: boolean;
}> {
  const user = await getServerUser();
  if (!user || !user.tenant_id) {
    return { count: 0, max: 10, isUnlimited: false };
  }

  const isPro = user.planType === 'pro' || user.planType === 'enterprise';
  if (isPro) {
    return { count: 0, max: 10, isUnlimited: true };
  }

  const supabase = await createClient();
  const startOfMonth = new Date();
  startOfMonth.setDate(1);
  startOfMonth.setHours(0, 0, 0, 0);

  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  const { count, error } = await (supabase as any)
    .from('ai_usage_logs')
    .select('*', { count: 'exact', head: true })
    .eq('tenant_id', user.tenant_id)
    .eq('feature_name', 'talent-draft')
    .gte('created_at', startOfMonth.toISOString());

  if (error) {
    console.error('[TalentDraft AI] usage logs fetch error:', error);
  }

  return { count: count || 0, max: 10, isUnlimited: false };
}
