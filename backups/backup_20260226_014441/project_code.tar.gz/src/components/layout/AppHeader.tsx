"use client";

import React from "react";
import Link from "next/link";
import { LogOut, Settings, Shield, ArrowLeft, Menu, X } from "lucide-react";
import { useRouter } from "next/navigation";
import { createClient } from "@/lib/supabase/client";
import { useAuth } from "@/lib/auth/context";
import { useMobileMenu } from "@/components/layout/MobileMenuContext";
import { APP_ROUTES } from "@/config/routes";
import { writeAuditLog } from "@/lib/log/actions";

interface AppHeaderProps {
  variant: 'portal' | 'admin' | 'saas';
  onMenuClick?: () => void;
}

export function AppHeader({ variant }: AppHeaderProps) {
  const { user } = useAuth();
  const router = useRouter();
  const supabase = createClient();
  const { isMobileMenuOpen, toggleMobileMenu } = useMobileMenu();

  const handleLogout = async () => {
    await writeAuditLog({ action: "LOGOUT", path: "/logout" }).catch(console.error);
    await supabase.auth.signOut();
    router.push(APP_ROUTES.AUTH.LOGIN);
    router.refresh();
  };

  const userName = user?.name || "Guest User";
  const role = user?.role || "member";
  const appRole = user?.appRole;

  let bgStyle = "rgba(255, 255, 255, 0.95)";
  let textColor = "text-slate-600";
  const logoGradient = "from-[#FF6B00] to-orange-600";
  
  if (variant === 'admin') {
    // #00738Aを中心に、上が明るく下が少し暗くなるグラデーション
    bgStyle = "linear-gradient(180deg, #008AA3 0%, #00738A 40%, #005F71 100%)";
    textColor = "text-white";
  } else if (variant === 'saas') {
    bgStyle = "#000B00";
    textColor = "text-white";
  }

  const headerStyle = {
    boxShadow: "0 10px 40px -10px rgba(0,0,0,0.2), inset 0 1px 1px rgba(255,255,255,0.2)",
    zIndex: 50,
    background: bgStyle,
  };

  const isEmployee = appRole === "employee";
  let label = "メンバー";
  if (isEmployee) label = "従業員";
  if (role === "admin") label = "管理者";
  if (role === "supaUser") label = "SaaS管理者";

  return (
    <header 
      style={headerStyle}
      className={`h-16 flex items-center justify-between px-4 md:px-6 shrink-0 sticky top-0 rounded-b-2xl transition-all duration-300 border-b ${variant === 'portal' ? 'border-slate-100/50' : 'border-white/10'} backdrop-blur-md`}
    >
      <div className="flex items-center gap-4">
        <button 
          onClick={toggleMobileMenu}
          className={`md:hidden p-2 rounded-md ${variant === 'portal' ? 'hover:bg-slate-100 text-slate-500' : 'hover:bg-white/10 text-white'}`}
          aria-label="メニューを開く"
        >
          {isMobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
        </button>
        
        <Link href={APP_ROUTES.TENANT.PORTAL} className="flex items-center gap-2 group">
          <div className={`w-8 h-8 rounded-lg bg-gradient-to-br ${logoGradient} flex items-center justify-center shadow-md group-hover:shadow-lg transition-all duration-300 ${variant !== 'portal' ? 'border border-white/20' : ''}`}>
             <span className="text-white font-bold text-lg tracking-tight">H</span>
          </div>
          <div 
             className={`text-xl md:text-2xl font-bold tracking-tighter drop-shadow-sm select-none ${variant === 'portal' ? 'bg-gradient-to-br from-[#FF6B00] to-orange-600 bg-clip-text text-transparent' : 'text-white'}`}
             style={{ textShadow: variant !== 'portal' ? "0 1px 2px rgba(0,0,0,0.2)" : "0 1px 1px rgba(0,0,0,0.05)" }}
          >
             HR-dx
          </div>
        </Link>
      </div>

      {/* Right Side */}
      <div className="flex items-center gap-3 md:gap-4">
        <div className={`h-6 w-px ${variant === 'portal' ? 'bg-slate-200' : 'bg-white/20'} mx-1 hidden md:block`}></div>

        <div className={`flex items-center gap-1 mr-2 border-r ${variant === 'portal' ? 'border-slate-200' : 'border-white/20'} pr-2 md:pr-4`}>
          {variant === 'portal' ? (
            <>
              <button 
                onClick={handleLogout}
                className="hidden md:flex items-center gap-2 px-3 py-2 text-sm font-medium text-slate-600 hover:text-accent-orange hover:bg-orange-50 rounded-md transition-all"
              >
                <LogOut className="w-4 h-4" />
                <span>ログアウト</span>
              </button>
              
              <div className="flex items-center gap-1 md:gap-3">
                {appRole && appRole !== 'employee' && (
                  <Link href={APP_ROUTES.TENANT.ADMIN}>
                    <button className="flex items-center gap-2 px-2 md:px-3 py-2 text-sm font-medium text-slate-600 hover:text-accent-orange hover:bg-orange-50 rounded-md transition-all" title="管理へ">
                      <Settings className="w-5 h-5 md:w-4 md:h-4 text-slate-500 md:text-inherit" />
                      <span className="hidden md:inline">管理へ</span>
                    </button>
                  </Link>
                )}

                {(appRole === 'developer' || role === 'supaUser') && (
                  <Link href={APP_ROUTES.SAAS.DASHBOARD}>
                    <button className="flex items-center gap-2 px-2 md:px-3 py-2 text-sm font-medium text-slate-600 hover:text-blue-600 hover:bg-blue-50 rounded-md transition-all" title="SaaS管理へ">
                      <Shield className="w-5 h-5 md:w-4 md:h-4 text-slate-500 md:text-inherit" />
                      <span className="hidden md:inline">SaaS管理へ</span>
                    </button>
                  </Link>
                )}
              </div>
            </>
          ) : (
             <Link href={APP_ROUTES.TENANT.PORTAL} className={`flex items-center gap-2 px-3 py-2 text-sm font-medium hover:bg-white/10 rounded-md transition-all text-white hover:text-white/90`}>
               <ArrowLeft className="w-4 h-4" />
               <span>ポータルへ戻る</span>
             </Link>
          )}
        </div>

        {/* User Profile */}
        <div className="flex items-center gap-3 pl-2 cursor-pointer hover:opacity-80 transition-opacity">
          <div className="text-right hidden md:block leading-tight">
            <div className={`text-sm font-semibold ${textColor}`}>{userName}</div>
            {variant !== 'portal' && (
              <div className={`text-[10px] px-2 py-0.5 rounded-full inline-block mt-1 font-medium tracking-wide shadow-sm border ${
                  role === 'supaUser' ? 'bg-gradient-to-r from-purple-50 to-white text-purple-700 border-purple-200' :
                  role === 'admin' ? 'bg-gradient-to-r from-orange-50 to-white text-orange-700 border-orange-200' :
                  'bg-gradient-to-r from-slate-50 to-white text-slate-600 border-slate-200'
              }`}>
                  {label}
              </div>
            )}
          </div>
          <div className={`w-9 h-9 rounded-full bg-gradient-to-br from-slate-100 to-slate-200 flex items-center justify-center text-slate-600 font-bold border-2 ${variant === 'portal' ? 'border-white ring-slate-100' : 'border-white/50 ring-white/20'} shadow-md ring-1`}>
            {userName.slice(0, 1)}
          </div>
        </div>
      </div>


    </header>
  );
}
