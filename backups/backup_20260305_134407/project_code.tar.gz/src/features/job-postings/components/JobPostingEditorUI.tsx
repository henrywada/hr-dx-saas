'use client'

import { useState, useTransition } from 'react'
import { useSearchParams } from 'next/navigation'
import { generateJobPostingFromMemo, updateJobPosting, updateJobPostingStatus } from '../actions'

interface Props {
  jobId: string
  initialMemo?: string
  initialTitle?: string
  initialDescription?: string
  initialStatus?: 'draft' | 'published' | 'closed'
}

export function JobPostingEditorUI({ 
  jobId, 
  initialMemo = '', 
  initialTitle = '', 
  initialDescription = '',
  initialStatus = 'draft'
}: Props) {
  // ※ 本来は raw_memo の保存(UPDATE)アクションも別途必要ですが、
  // ここでは AI生成を呼び出す部分にフォーカスしています。
  const searchParams = useSearchParams()
  const fromOnboarding = searchParams.get('from_onboarding') === 'true'

  const [memo, setMemo] = useState(initialMemo)
  const [title, setTitle] = useState(initialTitle)
  const [description, setDescription] = useState(initialDescription)
  const [status, setStatus] = useState<'draft' | 'published' | 'closed'>(initialStatus || 'draft')
  const [isPreview, setIsPreview] = useState(true)
  const [isPending, startTransition] = useTransition()
  const [isSaving, startSaveTransition] = useTransition()
  const [isPublishing, startPublishTransition] = useTransition()

  const handleGenerate = () => {
    startTransition(async () => {
      try {
        const result = await generateJobPostingFromMemo(jobId, memo)
        if (result.success && result.data) {
          setTitle(result.data.title)
          setDescription(result.data.description)
          alert('求人票が生成されました！')
        }
      } catch (error) {
        console.error(error)
        alert('生成中にエラーが発生しました: ' + (error instanceof Error ? error.message : String(error)))
      }
    })
  }

  const handleSave = () => {
    startSaveTransition(async () => {
      try {
        const result = await updateJobPosting(jobId, { title, description })
        if (result.success) {
          alert('求人票を保存しました！')
        }
      } catch (error) {
        console.error(error)
        alert('保存中にエラーが発生しました: ' + (error instanceof Error ? error.message : String(error)))
      }
    })
  }

  const handleTogglePublish = () => {
    const newStatus = status === 'published' ? 'draft' : 'published'
    startPublishTransition(async () => {
      try {
        const result = await updateJobPostingStatus(jobId, newStatus)
        if (result.success) {
          setStatus(newStatus)
          alert(`求人を「${newStatus === 'published' ? '公開' : '下書き'}」にしました！`)
        }
      } catch (error) {
        console.error(error)
        alert('ステータス変更中にエラーが発生しました')
      }
    })
  }

  return (
    <div className="space-y-6 max-w-4xl mx-auto">
      {fromOnboarding && (
        <div className="bg-gradient-to-r from-amber-50 to-amber-100 border border-amber-200 shadow-sm p-4 rounded-xl flex items-start gap-4 animate-in fade-in slide-in-from-top-4 duration-500">
          <div className="text-3xl animate-bounce pt-1">🎉</div>
          <div>
            <h2 className="text-lg font-bold text-amber-900 mb-1">会社情報のセットアップが完了しました！</h2>
            <p className="text-sm font-medium text-amber-800 leading-relaxed">抽出した自社の魅力を活かして、さっそく最初の求人票をAIで作ってみましょう。まずは現場からの募集要件を箇条書きでメモに入力してください。</p>
          </div>
        </div>
      )}

      {/* 現場メモ入力・表示エリア */}
      <div className="p-5 border rounded-lg bg-gray-50 shadow-sm">
        <h3 className="text-lg font-bold mb-3 flex items-center gap-2">
          📝 現場のメモ (raw_memo)
        </h3>
        <textarea
          value={memo}
          onChange={(e) => setMemo(e.target.value)}
          className="w-full h-32 p-3 border rounded-md focus:ring-2 focus:ring-blue-500 outline-none"
          placeholder={fromOnboarding ? "例：営業担当。BtoB経験者。コミュニケーション能力重視" : "現場からの箇条書きメモを入力してください... (※現在はローカルのstate管理のみです)"}
          disabled={isPending}
        />
        <div className="mt-4 flex justify-end">
          <button
            onClick={handleGenerate}
            disabled={isPending || !jobId}
            className="flex items-center gap-2 px-5 py-2.5 bg-gradient-to-r from-blue-600 to-indigo-600 text-white font-semibold rounded shadow hover:from-blue-700 hover:to-indigo-700 transition disabled:opacity-50"
          >
            {isPending ? (
              <>
                <svg className="animate-spin h-5 w-5 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                  <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                  <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                </svg>
                <span>AIが求人票を執筆中です...</span>
              </>
            ) : (
              <span>✨ AIで求人票を生成する</span>
            )}
          </button>
        </div>
      </div>

      {/* 生成結果プレビューエリア */}
      <div className="p-5 border rounded-lg bg-white shadow-sm space-y-5">
        <h3 className="text-lg font-bold mb-3 border-b pb-2">生成された求人票</h3>
        
        <div>
          <label className="block text-sm font-semibold text-gray-700 mb-1">募集タイトル</label>
          <input
            type="text"
            value={title}
            onChange={(e) => setTitle(e.target.value)}
            className="w-full p-2.5 border rounded-md bg-gray-50 text-gray-900 focus:ring-2 focus:ring-blue-500 outline-none"
            placeholder="AIによってタイトルが生成されます"
          />
        </div>
        
        <div>
        <div className="flex justify-between items-center mb-1">
          <label className="block text-sm font-semibold text-gray-700">求人詳細文 (HTML)</label>
          <button 
            onClick={() => setIsPreview(!isPreview)}
            className="text-xs text-blue-600 border border-blue-600 px-3 py-1 rounded bg-white hover:bg-blue-50"
          >
            {isPreview ? 'HTMLを編集する' : 'プレビューを見る'}
          </button>
        </div>
        
        {isPreview ? (
          <div className="w-full p-5 border block rounded-md bg-gray-50 min-h-[300px] text-sm text-gray-800 prose prose-sm max-w-none">
            {description ? (
              <div dangerouslySetInnerHTML={{ __html: description }} />
            ) : (
              <p className="text-gray-400 text-center mt-10">AIによって生成されたHTML形式の求人票がここにプレビューされます。</p>
            )}
          </div>
        ) : (
          <textarea
            value={description}
            onChange={(e) => setDescription(e.target.value)}
            className="w-full h-96 p-4 border rounded-md font-mono text-sm bg-white focus:ring-2 focus:ring-blue-500 outline-none"
            placeholder="<p>ここにHTMLを入力...</p>"
          />
        )}

        <div className="pt-4 flex justify-between items-center border-t mt-4">
          <button
            onClick={handleTogglePublish}
            disabled={isPublishing || !title || !description}
            className={`px-5 py-2.5 font-semibold rounded shadow transition disabled:opacity-50 ${
              status === 'published' 
                ? 'bg-yellow-500 hover:bg-yellow-600 text-white' 
                : 'bg-blue-600 hover:bg-blue-700 text-white'
            }`}
          >
            {isPublishing ? '更新中...' : status === 'published' ? '⏸ 公開を停止して下書きに戻す' : '🚀 求人サイト等へ公開する'}
          </button>
          
          <button
            onClick={handleSave}
            disabled={isSaving || isPending || !jobId}
            className="px-6 py-2.5 bg-green-600 text-white font-semibold rounded shadow hover:bg-green-700 transition disabled:opacity-50"
          >
            {isSaving ? '保存中...' : '💾 内容を更新・保存する'}
          </button>
        </div>
        </div>
      </div>
    </div>
  )
}
