'use server';

import { createAdminClient } from '@/lib/supabase/admin';

/**
 * SaaS管理ダッシュボード用: 全体の統計情報を取得する (RLSバイパス)
 */
export async function getSaasStats() {
  try {
    const supabase = createAdminClient();

    // 1. テナント数
    const { count: tenantCount } = await supabase
      .from('tenants')
      .select('*', { count: 'exact', head: true });

    // 2. 登録ユーザ数
    const { count: userCount } = await supabase
      .from('employees')
      .select('*', { count: 'exact', head: true });

    // 3. 公開サービス数
    const { count: publishedServiceCount } = await supabase
      .from('service')
      .select('*', { count: 'exact', head: true })
      .eq('release_status', '公開');
      
    // 4. 未公開サービス数
    const { count: unpublishedServiceCount } = await supabase
      .from('service')
      .select('*', { count: 'exact', head: true })
      .eq('release_status', '未公開');

    return {
      tenantCount: tenantCount ?? 0,
      userCount: userCount ?? 0,
      publishedServiceCount: publishedServiceCount ?? 0,
      unpublishedServiceCount: unpublishedServiceCount ?? 0,
    };
  } catch (error) {
    console.error('getSaasStats Error:', error);
    return { tenantCount: 0, userCount: 0, publishedServiceCount: 0, unpublishedServiceCount: 0 };
  }
}

/**
 * SaaS管理ダッシュボード用: 各テナントの契約・登録状況を取得する (RLSバイパス)
 */
export async function getSaasTenants() {
  try {
    const supabase = createAdminClient();

    const { data, error } = await supabase
      .from('tenants')
      .select(`
        id,
        name,
        employee_count,
        employees:employees(count)
      `);

    if (error) throw error;

    type TenantRow = {
      id: string;
      name: string;
      employee_count: number | null;
      employees: { count: number }[];
    };

    return (data as unknown as TenantRow[]).map((t) => ({
      id: t.id,
      name: t.name,
      contract_limit: t.employee_count ?? 0,
      actual_count: t.employees?.[0]?.count ?? 0
    }));
  } catch (error) {
    console.error('getSaasTenants Error:', error);
    return [];
  }
}

/**
 * SaaS管理ダッシュボード用: アクティビティログを取得する
 */
export async function getSaasActivity() {
  try {
    const supabase = createAdminClient();
    
    // 現在から14日前の日付を求める
    const pastDate = new Date();
    pastDate.setDate(pastDate.getDate() - 14);
    const startDateString = pastDate.toISOString().split('T')[0];

    // access_logsから直近2週間分のデータを取得する
    const { data, error } = await supabase
      .from('access_logs')
      .select('created_at')
      .gte('created_at', startDateString)
      .order('created_at', { ascending: false })
      .limit(50000); // 十分な件数を取得
      
    if (error) throw error;
    
    const countsMap = new Map<string, number>();
    
    // 過去14日分の空のカレンダー（0件）を用意して時系列を整える
    const sortedDates = [];
    for (let i = 13; i >= 0; i--) {
      const d = new Date();
      d.setDate(d.getDate() - i);
      const mm = (d.getMonth() + 1).toString().padStart(2, '0');
      const dd = d.getDate().toString().padStart(2, '0');
      const key = `${mm}/${dd}`;
      countsMap.set(key, 0);
      sortedDates.push(key);
    }
    
    // ログデータから日別に集計
    if (data) {
      data.forEach(log => {
        const d = new Date(log.created_at);
        const mm = (d.getMonth() + 1).toString().padStart(2, '0');
        const dd = d.getDate().toString().padStart(2, '0');
        const key = `${mm}/${dd}`;
        
        if (countsMap.has(key)) {
          countsMap.set(key, countsMap.get(key)! + 1);
        }
      });
    }

    return sortedDates.map(dateKey => ({
      date: dateKey,
      value: countsMap.get(dateKey) || 0,
    }));
    
  } catch (error) {
    console.error('getSaasActivity Error:', error);
    return [];
  }
}

/**
 * SaaS管理ダッシュボード用: テナント別の直近2週間アクセス数を集計する
 */
export async function getAccessCountByTenant(): Promise<Map<string, number>> {
  try {
    const supabase = createAdminClient();

    const pastDate = new Date();
    pastDate.setDate(pastDate.getDate() - 14);
    const startDateString = pastDate.toISOString().split('T')[0];

    const { data, error } = await supabase
      .from('access_logs')
      .select('tenant_id')
      .gte('created_at', startDateString)
      .not('tenant_id', 'is', null)
      .order('created_at', { ascending: false })
      .limit(50000);

    if (error) throw error;

    const countMap = new Map<string, number>();
    if (data) {
      data.forEach(log => {
        const tid = log.tenant_id as string;
        countMap.set(tid, (countMap.get(tid) || 0) + 1);
      });
    }
    return countMap;
  } catch (error) {
    console.error('getAccessCountByTenant Error:', error);
    return new Map();
  }
}
