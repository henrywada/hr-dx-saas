export default function Loading() {
  return (
    <div className="flex items-center justify-center h-full p-8 min-h-[50vh]">
      <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
    </div>
  )
}
