-- migration.sql
ALTER TABLE public.recruitment_jobs
ADD COLUMN media_advice TEXT;
