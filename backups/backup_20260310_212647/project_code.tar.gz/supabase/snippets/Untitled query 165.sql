DELETE FROM public.stress_check_results;
DELETE FROM public.stress_check_submissions;
DELETE FROM public.stress_check_responses;
