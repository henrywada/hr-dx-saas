COPY public.app_role (id, app_role, name) FROM stdin;
10000000-0000-0000-0000-000000000001	employee	従業員
10000000-0000-0000-0000-000000000002	hr_manager	人事マネージャー
\.
