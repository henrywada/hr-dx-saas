-- 1. 施工会社テーブルの修正 (tenant_idの追加とRLS設定)
DO $$ 
BEGIN
    IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='myou_companies' AND column_name='tenant_id') THEN
        ALTER TABLE public.myou_companies ADD COLUMN tenant_id uuid NOT NULL DEFAULT current_tenant_id();
    END IF;
END $$;

ALTER TABLE public.myou_companies ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "Tenant Isolation for myou_companies" ON public.myou_companies;
CREATE POLICY "Tenant Isolation for myou_companies" ON public.myou_companies
    FOR ALL TO authenticated USING (tenant_id = current_tenant_id());

-- 2. 製品テーブルの修正
DO $$ 
BEGIN
    IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='myou_products' AND column_name='tenant_id') THEN
        ALTER TABLE public.myou_products ADD COLUMN tenant_id uuid NOT NULL DEFAULT current_tenant_id();
    END IF;
END $$;

ALTER TABLE public.myou_products ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "Tenant Isolation for myou_products" ON public.myou_products;
CREATE POLICY "Tenant Isolation for myou_products" ON public.myou_products
    FOR ALL TO authenticated USING (tenant_id = current_tenant_id());

-- 3. 納入記録テーブルの修正
DO $$ 
BEGIN
    IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='myou_delivery_logs' AND column_name='tenant_id') THEN
        ALTER TABLE public.myou_delivery_logs ADD COLUMN tenant_id uuid NOT NULL DEFAULT current_tenant_id();
    END IF;
END $$;

ALTER TABLE public.myou_delivery_logs ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "Tenant Isolation for myou_delivery_logs" ON public.myou_delivery_logs;
CREATE POLICY "Tenant Isolation for myou_delivery_logs" ON public.myou_delivery_logs
    FOR ALL TO authenticated USING (tenant_id = current_tenant_id());

-- 4. アラートログテーブルの修正
DO $$ 
BEGIN
    IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='myou_alert_logs' AND column_name='tenant_id') THEN
        ALTER TABLE public.myou_alert_logs ADD COLUMN tenant_id uuid NOT NULL DEFAULT current_tenant_id();
    END IF;
END $$;

ALTER TABLE public.myou_alert_logs ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "Tenant Isolation for myou_alert_logs" ON public.myou_alert_logs;
CREATE POLICY "Tenant Isolation for myou_alert_logs" ON public.myou_alert_logs
    FOR ALL TO authenticated USING (tenant_id = current_tenant_id());
