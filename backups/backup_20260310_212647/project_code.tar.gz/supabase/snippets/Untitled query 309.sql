-- 回答データ(responses)があるのに提出記録(submissions)がない人を救済
INSERT INTO public.stress_check_submissions (
    tenant_id, 
    period_id, 
    employee_id, 
    status, 
    submitted_at
)
SELECT DISTINCT 
    tenant_id, 
    period_id, 
    employee_id, 
    'submitted', -- ★ ここを修正しています
    now()
FROM 
    public.stress_check_responses
ON CONFLICT (period_id, employee_id) DO NOTHING;
