-- stress_check_periods に questionnaire_type カラムがあることを再確認し、
-- テナントごとのデフォルト設定を持つ場合は tenants テーブル等に拡張も可能ですが、
-- 今回は「実施期間（period）」ごとに選択する運用とします。

-- 回答保存用のRLSポリシー（未設定の場合）
ALTER TABLE public.stress_check_responses ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can insert their own responses" ON public.stress_check_responses
  FOR INSERT WITH CHECK (
    auth.uid() = (SELECT user_id FROM employees WHERE id = employee_id)
  );

CREATE POLICY "Users can view their own responses" ON public.stress_check_responses
  FOR SELECT USING (
    auth.uid() = (SELECT user_id FROM employees WHERE id = employee_id)
  );