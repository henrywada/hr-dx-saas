-- ==========================================
-- 1. 回答選択肢マスタ (16行)
-- ==========================================
CREATE TABLE public.stress_check_response_options (
  id uuid DEFAULT gen_random_uuid() PRIMARY KEY,
  scale_type text NOT NULL CHECK (scale_type IN ('A', 'B', 'C', 'D')),
  score int NOT NULL CHECK (score BETWEEN 1 AND 4),
  label text NOT NULL,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

ALTER TABLE public.stress_check_response_options ENABLE ROW LEVEL SECURITY;
-- システムマスタのため全認証ユーザーに読み取りを許可
CREATE POLICY "Enable read access for authenticated users" 
  ON public.stress_check_response_options FOR SELECT TO authenticated USING (true);


-- ==========================================
-- 2. 高ストレス者選定基準マスタ (4行)
-- ==========================================
CREATE TABLE public.stress_check_high_stress_criteria (
  id uuid DEFAULT gen_random_uuid() PRIMARY KEY,
  evaluation_method text NOT NULL CHECK (evaluation_method IN ('raw_score', 'converted_score')),
  question_count int NOT NULL CHECK (question_count IN (23, 57)),
  condition_1_b_threshold int NOT NULL,       -- 基準①: 領域Bの閾値
  condition_2_ac_threshold int NOT NULL,      -- 基準②: 領域A+Cの閾値
  condition_2_b_threshold int NOT NULL,       -- 基準②: 領域Bの閾値
  description text,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

ALTER TABLE public.stress_check_high_stress_criteria ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Enable read access for authenticated users" 
  ON public.stress_check_high_stress_criteria FOR SELECT TO authenticated USING (true);


-- ==========================================
-- 3. 素点換算表マスタ (38行: 19尺度 × 男女)
-- ==========================================
CREATE TABLE public.stress_check_scale_conversions (
  id uuid DEFAULT gen_random_uuid() PRIMARY KEY,
  scale_id text NOT NULL,
  scale_name text NOT NULL,
  gender text NOT NULL CHECK (gender IN ('male', 'female')),
  -- 評価点(1〜5)に対応する素点の範囲をJSONBで管理
  -- 例: {"1": [3, 5], "2": [6, 7], "3": [8, 9], "4": [10, 11], "5": [12, 12]}
  score_mapping jsonb NOT NULL,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now(),
  UNIQUE(scale_id, gender)
);

ALTER TABLE public.stress_check_scale_conversions ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Enable read access for authenticated users" 
  ON public.stress_check_scale_conversions FOR SELECT TO authenticated USING (true);