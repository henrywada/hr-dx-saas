DELETE FROM access_logs;
