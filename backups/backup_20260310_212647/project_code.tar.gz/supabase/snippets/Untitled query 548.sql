SELECT current_setting('postgrest.jwt_secret');
