-- 1. 最小限の基礎データ（テナント・ロール）の投入
-- 既存のデータがある場合はスキップされます
DO $$
DECLARE
    target_user_id uuid := 'a99a99f5-b755-4519-8c4d-eddc9d7f86c7'; -- ←ここにコピーしたUUIDを貼り付けてください
    admin_tenant_id uuid := gen_random_uuid();
    admin_role_id uuid := '10000000-0000-0000-0000-000000000002'; -- バックアップにあった人事マネージャー相当のID
BEGIN
    -- A. システム管理用のダミーテナント作成
    INSERT INTO public.tenants (id, name, plan_type, max_employees)
    VALUES (admin_tenant_id, 'SaaS管理用（システム）', 'pro', 9999)
    ON CONFLICT DO NOTHING;

    -- B. 基本ロールの作成
    INSERT INTO public.app_role (id, app_role, name)
    VALUES 
        ('10000000-0000-0000-0000-000000000001', 'employee', '一般従業員'),
        (admin_role_id, 'admin', 'システム管理者')
    ON CONFLICT DO NOTHING;

    -- C. 従業員レコードの作成（getServerUserが正常に動作するために必要）
    INSERT INTO public.employees (tenant_id, user_id, name, app_role_id, active_status)
    VALUES (admin_tenant_id, target_user_id, 'SaaS SuperUser', admin_role_id, 'active')
    ON CONFLICT (user_id) DO UPDATE SET tenant_id = EXCLUDED.tenant_id;

    -- D. auth.users のメタデータを更新して supaUser 権限を付与
    UPDATE auth.users
    SET raw_user_meta_data = jsonb_set(
        COALESCE(raw_user_meta_data, '{}'::jsonb),
        '{role}',
        '"supaUser"'
    )
    WHERE id = target_user_id;

    RAISE NOTICE 'wada007@gmail.com を supaUser に設定し、基礎データを整備しました。';
END $$;
