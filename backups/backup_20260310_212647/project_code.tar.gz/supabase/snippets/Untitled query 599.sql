SELECT 'stress_check_results' as table_name, count(*) as remaining FROM public.stress_check_results
UNION ALL
SELECT 'stress_check_submissions', count(*) FROM public.stress_check_submissions
UNION ALL
SELECT 'stress_check_responses', count(*) FROM public.stress_check_responses;
