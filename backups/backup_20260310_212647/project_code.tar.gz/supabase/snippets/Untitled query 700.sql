SELECT * FROM cron.job;
