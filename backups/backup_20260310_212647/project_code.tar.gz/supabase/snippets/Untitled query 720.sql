-- 1. 最小限の基礎データの投入
DO $$
DECLARE
    target_user_id uuid := 'a99a99f5-b755-4519-8c4d-eddc9d7f86c7'; -- ←Authenticationで作成したUUIDを貼り付けてください
    admin_tenant_id uuid := gen_random_uuid();
    admin_role_id uuid := '10000000-0000-0000-0000-000000000002';
BEGIN
    -- A. システム管理用のテナント作成
    INSERT INTO public.tenants (id, name, plan_type, max_employees)
    VALUES (admin_tenant_id, 'SaaS管理用（システム）', 'pro', 9999)
    ON CONFLICT DO NOTHING;

    -- B. 基本ロールの作成
    INSERT INTO public.app_role (id, app_role, name)
    VALUES 
        ('10000000-0000-0000-0000-000000000001', 'employee', '一般従業員'),
        (admin_role_id, 'admin', 'システム管理者')
    ON CONFLICT DO NOTHING;

    -- C. 従業員レコードの作成（エラー回避のため単純な存在チェックに変更）
    IF NOT EXISTS (SELECT 1 FROM public.employees WHERE user_id = target_user_id) THEN
        INSERT INTO public.employees (tenant_id, user_id, name, app_role_id, active_status)
        VALUES (admin_tenant_id, target_user_id, 'SaaS SuperUser', admin_role_id, 'active');
    ELSE
        UPDATE public.employees 
        SET tenant_id = admin_tenant_id, 
            app_role_id = admin_role_id 
        WHERE user_id = target_user_id;
    END IF;

    -- D. auth.users のメタデータを更新
    UPDATE auth.users
    SET raw_user_meta_data = jsonb_set(
        COALESCE(raw_user_meta_data, '{}'::jsonb),
        '{role}',
        '"supaUser"'
    )
    WHERE id = target_user_id;

    RAISE NOTICE 'wada007@gmail.com を supaUser に設定完了しました。';
END $$;