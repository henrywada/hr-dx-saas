-- ==========================================
-- 1. 回答選択肢マスタ データ挿入 (16行)
-- ==========================================
INSERT INTO public.stress_check_response_options (scale_type, score, label) VALUES
  ('A', 4, 'そうだ'), ('A', 3, 'まあそうだ'), ('A', 2, 'ややちがう'), ('A', 1, 'ちがう'),
  ('B', 1, 'ほとんどなかった'), ('B', 2, 'ときどきあった'), ('B', 3, 'しばしばあった'), ('B', 4, 'ほとんどいつもあった'),
  ('C', 4, '非常に'), ('C', 3, 'かなり'), ('C', 2, '多少'), ('C', 1, '全くない'),
  ('D', 4, '満足'), ('D', 3, 'まあ満足'), ('D', 2, 'やや不満'), ('D', 1, '不満');


-- ==========================================
-- 2. 高ストレス者選定基準マスタ データ挿入 (4行)
-- ※厚労省マニュアルに基づく標準基準
-- ==========================================
INSERT INTO public.stress_check_high_stress_criteria (evaluation_method, question_count, condition_1_b_threshold, condition_2_ac_threshold, condition_2_b_threshold, description) VALUES
  -- 57問: 素点合計方式 (点数が高いほど高ストレス)
  ('raw_score', 57, 77, 76, 63, '基準①:Bが77点以上 / 基準②:A+Cが76点以上 かつ Bが63点以上'),
  -- 57問: 5段階換算方式 (評価点が低いほど高ストレス)
  ('converted_score', 57, 12, 26, 17, '基準①:Bの評価点12点以下 / 基準②:A+Cが26点以下 かつ Bが17点以下'),
  -- 23問: 素点合計方式 (23問版はB領域の比重が異なるため暫定値 ※必要に応じて調整)
  ('raw_score', 23, 31, 30, 25, '23問版 素点合計方式'),
  -- 23問: 5段階換算方式
  ('converted_score', 23, 6, 13, 8, '23問版 5段階換算方式');


-- ==========================================
-- 3. 素点換算表マスタ データ挿入 (38行)
-- ※JSONB内の配列は [最小素点, 最大素点] を表します。
-- ※厚労省標準換算表に基づき、評価点1が最もストレスが高く、5が最もストレスが低い状態です。
-- ==========================================
WITH scales AS (
  SELECT '1' AS id, '心理的な仕事の負担（量）' AS name UNION ALL
  SELECT '2', '心理的な仕事の負担（質）' UNION ALL
  SELECT '3', '自覚的な身体的負担度' UNION ALL
  SELECT '4', '職場の対人関係でのストレス' UNION ALL
  SELECT '5', '職場環境によるストレス' UNION ALL
  SELECT '6', '仕事のコントロール度' UNION ALL
  SELECT '7', '技能の活用度' UNION ALL
  SELECT '8', '仕事の適性度' UNION ALL
  SELECT '9', '働きがい' UNION ALL
  SELECT '10', '活気' UNION ALL
  SELECT '11', 'イライラ感' UNION ALL
  SELECT '12', '疲労感' UNION ALL
  SELECT '13', '不安感' UNION ALL
  SELECT '14', '抑うつ感' UNION ALL
  SELECT '15', '身体愁訴' UNION ALL
  SELECT '16', '上司からのサポート' UNION ALL
  SELECT '17', '同僚からのサポート' UNION ALL
  SELECT '18', '家族・友人からのサポート' UNION ALL
  SELECT '19', '仕事や生活の満足度'
)
INSERT INTO public.stress_check_scale_conversions (scale_id, scale_name, gender, score_mapping)
SELECT 
  id, 
  name, 
  gender, 
  -- ※下記はダミーの配分例です。実際の厚労省「素点換算表」の正確な数値に合わせる場合は、
  -- 実装後にJSONBの配列値をアップデートしてください。
  '{"1": [3, 5], "2": [6, 7], "3": [8, 9], "4": [10, 11], "5": [12, 12]}'::jsonb
FROM scales
CROSS JOIN (VALUES ('male'), ('female')) AS g(gender);