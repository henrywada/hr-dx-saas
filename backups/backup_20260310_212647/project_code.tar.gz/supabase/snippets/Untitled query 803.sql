INSERT INTO stress_check_periods (
  tenant_id,
  title,
  questionnaire_type,
  status,
  start_date,
  end_date,
  fiscal_year
)
VALUES (
  '421f9b0d-5db0-47b3-8d48-203b9213dc00',
  '2024年度 第1回ストレスチェック',
  '57',
  'active',
  '2024-01-01',
  '2026-12-31',
  2024
);
