-- 回答保存用のRLSポリシー（従業員は自分の回答のみ作成・参照可能）
ALTER TABLE public.stress_check_responses ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can insert their own responses" ON public.stress_check_responses
  FOR INSERT WITH CHECK (
    auth.uid() = (SELECT user_id FROM employees WHERE id = employee_id)
  );

CREATE POLICY "Users can view their own responses" ON public.stress_check_responses
  FOR SELECT USING (
    auth.uid() = (SELECT user_id FROM employees WHERE id = employee_id)
  );