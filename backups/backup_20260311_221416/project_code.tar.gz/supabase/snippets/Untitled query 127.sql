-- 2. 上記でユーザーが見つかったら、手動でトークンを再生成してみる
SELECT public.generate_recovery_token(
  (SELECT id FROM auth.users WHERE email = 'sample1@gmail.com'),
  336
) as new_token;
