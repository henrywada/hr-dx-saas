CREATE OR REPLACE FUNCTION public.delete_auth_user(p_user_id UUID)
RETURNS VOID
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = auth, public
AS $$
BEGIN
    -- 外部キー制約のあるテーブルから削除
    DELETE FROM public.employees WHERE user_id = p_user_id;
    -- Identityを削除
    DELETE FROM auth.identities WHERE user_id = p_user_id;
    -- ユーザー本体を削除
    DELETE FROM auth.users WHERE id = p_user_id;
END;
$$;

-- スキーマキャッシュの更新
NOTIFY pgrst, 'reload schema';
