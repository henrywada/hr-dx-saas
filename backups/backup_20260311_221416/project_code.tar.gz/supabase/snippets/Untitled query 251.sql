UPDATE auth.users SET confirmed_at = NOW() WHERE confirmed_at IS NULL AND email_confirmed_at IS NOT NULL;
