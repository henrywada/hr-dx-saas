-- トークン検証関数
CREATE OR REPLACE FUNCTION public.verify_recovery_token(
  p_email TEXT,
  p_token TEXT,
  p_expiry_hours INT DEFAULT 168
) RETURNS UUID
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = auth, public, extensions
AS $$
DECLARE
  v_user_id UUID;
  v_stored_token TEXT;
  v_sent_at TIMESTAMPTZ;
BEGIN
  SELECT id, recovery_token, recovery_sent_at
  INTO v_user_id, v_stored_token, v_sent_at
  FROM auth.users
  WHERE email = p_email;

  IF v_user_id IS NULL THEN
    RAISE EXCEPTION 'ユーザーが見つかりません';
  END IF;

  IF v_stored_token IS NULL OR v_stored_token = '' THEN
    RAISE EXCEPTION 'リカバリートークンが設定されていません';
  END IF;

  IF v_sent_at + (p_expiry_hours || ' hours')::interval < NOW() THEN
    RAISE EXCEPTION 'トークンの有効期限が切れています';
  END IF;

  IF crypt(p_token, v_stored_token) != v_stored_token THEN
    RAISE EXCEPTION 'トークンが無効です';
  END IF;

  RETURN v_user_id;
END;
$$;

-- パスワード更新関数
CREATE OR REPLACE FUNCTION public.update_user_password(
  p_user_id UUID,
  p_new_password TEXT
) RETURNS VOID
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = auth, public, extensions
AS $$
BEGIN
  UPDATE auth.users
  SET encrypted_password = crypt(p_new_password, gen_salt('bf')),
      recovery_token = '',
      updated_at = NOW()
  WHERE id = p_user_id;
END;
$$;

-- スキーマキャッシュをリロード
NOTIFY pgrst, 'reload schema';
