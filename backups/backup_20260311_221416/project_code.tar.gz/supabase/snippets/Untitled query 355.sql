SELECT id, email, aud, role, encrypted_password IS NOT NULL as has_password,
       email_confirmed_at IS NOT NULL as email_confirmed,
       raw_app_meta_data, raw_user_meta_data
FROM auth.users 
WHERE email = 'abc@gmail.com';
