-- generate_recovery_token: 平文トークンを保存する（ハッシュ化しない）
CREATE OR REPLACE FUNCTION public.generate_recovery_token(
  p_user_id UUID,
  p_expiry_hours INT DEFAULT 168
) RETURNS TEXT
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = auth, public, extensions
AS $$
DECLARE
  v_token TEXT;
BEGIN
  -- 32バイトのランダム hex トークンを生成（平文のまま保存）
  v_token := encode(gen_random_bytes(32), 'hex');

  UPDATE auth.users
  SET 
    recovery_token = v_token,
    recovery_sent_at = NOW()
  WHERE id = p_user_id;

  RETURN v_token;
END;
$$;

-- verify_recovery_token: 平文で直接比較する
CREATE OR REPLACE FUNCTION public.verify_recovery_token(
  p_email TEXT,
  p_token TEXT,
  p_expiry_hours INT DEFAULT 336
) RETURNS UUID
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = auth, public, extensions
AS $$
DECLARE
  v_user_id UUID;
  v_stored_token TEXT;
  v_sent_at TIMESTAMPTZ;
BEGIN
  -- メールアドレスでユーザーを検索（トークン比較はWHERE外で行う）
  SELECT id, recovery_token, recovery_sent_at
  INTO v_user_id, v_stored_token, v_sent_at
  FROM auth.users
  WHERE email = p_email;

  IF v_user_id IS NULL THEN
    RAISE EXCEPTION 'ユーザーが見つかりません';
  END IF;

  IF v_stored_token IS NULL OR v_stored_token = '' THEN
    RAISE EXCEPTION 'リカバリートークンが設定されていません';
  END IF;

  -- 有効期限チェック
  IF v_sent_at IS NULL OR v_sent_at + (p_expiry_hours || ' hours')::interval < NOW() THEN
    RAISE EXCEPTION 'トークンの有効期限が切れています';
  END IF;

  -- 平文で直接比較
  IF v_stored_token != p_token THEN
    RAISE EXCEPTION 'トークンが一致しません';
  END IF;

  -- トークン消費（再利用防止）
  UPDATE auth.users
  SET recovery_token = '', recovery_sent_at = NULL
  WHERE id = v_user_id;

  RETURN v_user_id;
END;
$$;

NOTIFY pgrst, 'reload schema';
