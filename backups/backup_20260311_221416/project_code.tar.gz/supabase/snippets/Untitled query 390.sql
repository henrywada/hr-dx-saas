NOTIFY pgrst, 'reload schema';
