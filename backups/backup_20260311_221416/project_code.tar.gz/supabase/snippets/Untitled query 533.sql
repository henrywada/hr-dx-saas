DO $$
DECLARE
    v_user_id UUID;
BEGIN
    -- 1. ユーザーIDを取得
    SELECT id INTO v_user_id FROM auth.users WHERE email = 'test1@gmail.com';

    IF v_user_id IS NOT NULL THEN
        -- 2. 外部キー制約がある関連データを先に削除 (必要に応じて追加)
        DELETE FROM public.employees WHERE user_id = v_user_id;
        
        -- 3. auth.identities を先に削除
        DELETE FROM auth.identities WHERE user_id = v_user_id;
        
        -- 4. auth.users を削除
        DELETE FROM auth.users WHERE id = v_user_id;
        
        RAISE NOTICE 'User % deleted successfully.', v_user_id;
    ELSE
        RAISE NOTICE 'User not found.';
    END IF;
END $$;
