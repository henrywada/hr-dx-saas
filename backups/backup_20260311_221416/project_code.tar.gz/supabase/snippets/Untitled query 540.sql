CREATE OR REPLACE FUNCTION public.create_auth_user(
    p_email TEXT,
      p_password text) RETURNS uuid  LANGUAGE plpgsql
        SECURITY definer  SET search_path = auth, publicAS $$
        declare  v_user_id UUID;
          v_encrypted_password TEXT;
          begin  v_user_id := gen_random_uuid();
            v_encrypted_password := crypt(p_password, gen_salt('bf'));

              INSERT INTO auth.users (
                    instance_id, id, aud, role,
                        email, encrypted_password,
                            email_confirmed_at, created_at, updated_at,
                                confirmation_token, recovery_token,
                                    is_super_admin, raw_app_meta_data, raw_user_meta_data  ) VALUES (
                                          '00000000-0000-0000-0000-000000000000',
                                              v_user_id, 'authenticated', 'authenticated',
                                                  p_email, v_encrypted_password,
                                                      NOW(), NOW(), NOW(),
                                                          '', '',
                                                              false,
                                                                  jsonb_build_object('provider', 'email', 'providers', jsonb_build_array('email')),
                                                                      '{}'::json_object  );

                                                                        INSERT INTO auth.identities (
                                                                              id, user_id, provider_id, identity_data, provider,
                                                                                  created_at, updated_at, last_sign_in_at  ) VALUES (
                                                                                        gen_random_uuid(), v_user_id, p_email,
                                                                                            jsonb_build_object('sub', v_user_id::text, 'email', p_email, 'email_verified', true, 'provider', 'email'),
                                                                                                'email', NOW(), NOW(), NOW()
                                                                                  );

                                                                                    RETURN v_user_id;
                                                                                    END;
                                                                                    $$;
                                                                                    
                                                                                  )
                                                                        )
                                    )
              )
)