CREATE EXTENSION IF NOT EXISTS pgcrypto;

CREATE OR REPLACE FUNCTION public.create_auth_user(
  p_email TEXT,
    p_password text) RETURNS uuidLANGUAGE plpgsql
    SECURITY definerSET search_path = auth, publicAS $$
    DECLARE
      v_user_id UUID;
        v_encrypted_password TEXT;
        begin  v_user_id := gen_random_uuid();
          v_encrypted_password := crypt(p_password, gen_salt('bf'));

            INSERT INTO auth.users (
                  instance_id, id, aud, role,
                      email, encrypted_password,
                          email_confirmed_at, created_at, updated_at,
                              confirmation_token, recovery_token,
                                  is_super_admin, raw_app_meta_data, raw_user_meta_data  ) VALUES (
                                        '00000000-0000-0000-0000-000000000000',
                                            v_user_id, 'authenticated', 'authenticated',
                                                p_email, v_encrypted_password,
                                                    NOW(), NOW(), NOW(),
                                                        '', '',
                                                            false,
                                                                jsonb_build_object('provider', 'email', 'providers', jsonb_build_array('email')),
                                                                    '{}'::json_object  );
                                                                      INSERT INTO auth.identities (
                                                                            id, user_id, provider_id, identity_data, provider,
                                                                                created_at, updated_at, last_sign_in_at  ) VALUES (
                                                                                      gen_random_uuid(), v_user_id, p_email,
                                                                                          jsonb_build_object('sub', v_user_id::text, 'email', p_email, 'email_verified', true, 'provider', 'email'),
                                                                                              'email', NOW(), NOW(), NOW()
                                                                                                );

                                                                                                  RETURN v_user_id;
                                                                                                  END;
                                                                                                  $$;
                                                                                                  CREATE OR REPLACE FUNCTION public.generate_recovery_token(
                                                                                                      p_user_id UUID,
                                                                                                        p_expiry_hours INT DEFAULT 336
                                                                                                        ) RETURNS textLANGUAGE plpgsql
                                                                                                        SECURITY definerSET search_path = auth, publicAS $$
                                                                                                        declare  v_token TEXT;
                                                                                                        begin  v_token := encode(gen_random_bytes(32), 'hex');
                                                                                                          UPDATE auth.users  SET recovery_token = crypt(v_token, gen_salt('bf')), recovery_sent_at = NOW()
                                                                                                            WHERE id = p_user_id;
                                                                                                              RETURN v_token;
                                                                                                              END;
                                                                                                              $$;
                                                                                                              CREATE OR REPLACE FUNCTION public.delete_auth_user(
                                                                                                                  p_user_id uuid) RETURNS storage.vector_indexesLANGUAGE plpgsql
                                                                                                                  SECURITY definerSET search_path = auth, publicAS $$
                                                                                                                  BEGIN
                                                                                                                    DELETE FROM auth.identities WHERE user_id = p_user_id;
                                                                                                                      DELETE FROM auth.sessions WHERE user_id = p_user_id;
                                                                                                                        DELETE FROM auth.users WHERE id = p_user_id;
                                                                                                                        END;
                                                                                                                        $$;
                                                                                                                        
                                                                                                              )
                                                                                                  )
                                                                                )
                                                                      )
                                  )
            )