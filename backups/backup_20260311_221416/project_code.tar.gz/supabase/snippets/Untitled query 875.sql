-- sample1のuser_idを取得してトークン再生成
DO $$
DECLARE
  v_user_id UUID;
  v_token TEXT;
BEGIN
  SELECT id INTO v_user_id FROM auth.users WHERE email = 'sample1@gmail.com';
  RAISE NOTICE 'user_id: %', v_user_id;
  
  SELECT public.generate_recovery_token(v_user_id, 336) INTO v_token;
  RAISE NOTICE 'generated token: %', left(v_token, 20);
  
  -- 保存されたか確認
  SELECT recovery_token INTO v_token FROM auth.users WHERE id = v_user_id;
  RAISE NOTICE 'stored token: %', left(v_token, 20);
END $$;
