-- 1. ユーザーの存在とトークン状態を確認
SELECT 
  id,
  email,
  CASE 
    WHEN recovery_token IS NULL THEN 'NULL'
    WHEN recovery_token = '' THEN '空文字（問題あり）'
    ELSE '設定済み: ' || left(recovery_token, 20) || '...'
  END as token_status,
  recovery_sent_at
FROM auth.users
WHERE email = 'sample1@gmail.com';
